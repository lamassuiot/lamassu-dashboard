from __future__ import annotations

import logging
import os
import shutil
import signal
import subprocess
import threading
from collections.abc import Callable
from contextlib import nullcontext
from typing import Any

from live_cbom.analysis import ObservationProcessor
from live_cbom.capture.listener import PacketListener, read_pcap
from live_cbom.capture.pyshark_adapter import observation_from_packet
from live_cbom.cbom.registry import CryptoRegistry
from live_cbom.config import Config
from live_cbom.observation_io import ObservationWriter, iter_observations
from live_cbom.observations import ObservationMapping
from live_cbom.output.writer import PeriodicWriter

LOGGER = logging.getLogger(__name__)

def _make_packet_handler(
    registry: CryptoRegistry,
    seen_connections: dict[str, bool],
    observation_sink: Callable[[ObservationMapping], None] | None = None,
) -> Any:
    """Return an ``on_packet`` callable shared by live and PCAP modes.

    The returned function processes a single decoded pyshark packet: it tracks
    TCP connections, registers TLS handshakes, and stores certificate data in
    the provided *registry*.

    Args:
        registry:         Shared :class:`CryptoRegistry` to populate.
        seen_connections: Mutable dict used to deduplicate connection log lines.
    """
    processor = ObservationProcessor(registry, seen_connections)

    def on_packet(pkt: Any) -> None:
        observation = observation_from_packet(pkt)
        if observation_sink is not None:
            observation_sink(observation)
        processor.ingest(observation)

    return on_packet


def run(config: Config) -> None:
    registry = CryptoRegistry(compact=config.compact)
    listener = PacketListener(config.interface, keylog_path=config.keylog_path)
    writer = PeriodicWriter(registry=registry, config=config)
    stop_event = threading.Event()
    seen_connections: dict[str, bool] = {}

    observation_context = (
        ObservationWriter(config.observations_output_path)
        if config.observations_output_path
        else nullcontext(None)
    )
    with observation_context as observation_writer:
        on_packet = _make_packet_handler(
            registry,
            seen_connections,
            observation_writer.write if observation_writer else None,
        )
        listener.register_callback(on_packet)

        def shutdown_handler(signum: int, _frame: Any) -> None:
            LOGGER.info("Received signal %s, shutting down...", signum)
            stop_event.set()

        signal.signal(signal.SIGINT, shutdown_handler)
        signal.signal(signal.SIGTERM, shutdown_handler)

        listener.start()
        writer.start()
        LOGGER.info(
            "Live CBOM daemon started on interface=%s",
            config.interface,
        )

        stop_event.wait()
        listener.stop()
        writer.stop()
        try:
            writer.flush_once()
        except Exception:
            LOGGER.exception("Final CBOM flush failed")


def run_pcap(config: Config, pcap_path: str) -> None:
    """Generate a CBOM from an offline PCAP/PCAPng file.

    All packets in *pcap_path* are processed synchronously using the same
    extraction pipeline as the live capture mode.  A single CBOM is written
    to ``config.output_path`` once the entire file has been read.

    Args:
        config:    Runtime configuration (output path, component metadata, …).
        pcap_path: Path to the ``.pcap`` or ``.pcapng`` file to analyse.
    """
    LOGGER.info("Reading PCAP file: %s", pcap_path)
    registry = CryptoRegistry(compact=config.compact)
    seen_connections: dict[str, bool] = {}
    observation_context = (
        ObservationWriter(config.observations_output_path)
        if config.observations_output_path
        else nullcontext(None)
    )
    with observation_context as observation_writer:
        on_packet = _make_packet_handler(
            registry,
            seen_connections,
            observation_writer.write if observation_writer else None,
        )
        read_pcap(pcap_path, on_packet, keylog_path=config.keylog_path)

    writer = PeriodicWriter(registry=registry, config=config)
    try:
        writer.flush_once()
    except Exception:
        LOGGER.exception("CBOM flush failed after PCAP processing")
    LOGGER.info(
        "PCAP analysis complete: %d unique connections observed, CBOM written to %s",
        len(seen_connections),
        config.output_path,
    )


def run_observations(config: Config, observations_path: str) -> None:
    """Generate a CBOM from normalized JSON, NDJSON/JSONL, or YAML."""
    LOGGER.info("Reading normalized observations: %s", observations_path)
    registry = CryptoRegistry(compact=config.compact)
    processor = ObservationProcessor(registry)
    count = processor.ingest_many(iter_observations(observations_path))

    writer = PeriodicWriter(registry=registry, config=config)
    writer.flush_once()
    LOGGER.info(
        "Observation analysis complete: %d observations, CBOM written to %s",
        count,
        config.output_path,
    )


def _start_background_capture(interface: str, capture_path: str) -> subprocess.Popen:
    """Start a subprocess that continuously writes raw packets to *capture_path*.

    Prefers ``dumpcap`` (the minimal-privilege capture helper bundled with
    Wireshark/tshark) and falls back to ``tshark -w`` if it isn't installed.
    """
    dumpcap_bin = shutil.which("dumpcap")
    if dumpcap_bin:
        cmd = [dumpcap_bin, "-i", interface, "-w", capture_path]
    else:
        tshark_bin = shutil.which("tshark")
        if not tshark_bin:
            raise RuntimeError("Neither 'dumpcap' nor 'tshark' found on PATH; required for rolling-capture mode")
        cmd = [tshark_bin, "-i", interface, "-w", capture_path]
    LOGGER.info("Starting background capture: %s", " ".join(cmd))
    return subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def _stop_background_capture(proc: subprocess.Popen) -> None:
    proc.terminate()
    try:
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        proc.kill()


def run_rolling(config: Config, capture_dir: str) -> None:
    """Live-capture mode that re-dissects a single growing pcap file instead of
    dissecting packets as they arrive.

    Live ``sniff_continuously()`` (see :func:`run`) dissects each packet the
    instant it's captured. For TLS 1.3, the ``Certificate`` record is
    encrypted with the handshake traffic secret, and eCapture's keylog entry
    for that secret can land in the keylog file a few milliseconds *after*
    the packet already reached tshark — a race live dissection can never win,
    since there's no second pass. This mode sidesteps the race: a background
    capture process appends to one pcap file, and every ``flush_interval_sec``
    the *entire* file is re-read with the (by-then more complete) keylog file
    applied. Registry entries are upserted by stable key, so repeatedly
    re-processing the same packets is safe.

    Args:
        config:      Runtime configuration (interface, output path, keylog path, …).
        capture_dir: Directory to hold the rolling ``rolling.pcapng`` capture file.
    """
    os.makedirs(capture_dir, exist_ok=True)
    capture_path = os.path.join(capture_dir, "rolling.pcapng")

    capture_proc = _start_background_capture(config.interface, capture_path)

    registry = CryptoRegistry(compact=config.compact)
    seen_connections: dict[str, bool] = {}
    writer = PeriodicWriter(registry=registry, config=config)
    stop_event = threading.Event()

    def shutdown_handler(signum: int, _frame: Any) -> None:
        LOGGER.info("Received signal %s, shutting down...", signum)
        stop_event.set()

    signal.signal(signal.SIGINT, shutdown_handler)
    signal.signal(signal.SIGTERM, shutdown_handler)

    LOGGER.info(
        "Rolling-capture CBOM daemon started interface=%s capture_file=%s keylog=%s",
        config.interface,
        capture_path,
        config.keylog_path,
    )

    try:
        while not stop_event.is_set():
            stop_event.wait(config.flush_interval_sec)
            if stop_event.is_set():
                break
            if not os.path.exists(capture_path) or os.path.getsize(capture_path) == 0:
                continue
            try:
                observation_context = (
                    ObservationWriter(config.observations_output_path)
                    if config.observations_output_path
                    else nullcontext(None)
                )
                with observation_context as observation_writer:
                    on_packet = _make_packet_handler(
                        registry,
                        seen_connections,
                        (
                            observation_writer.write
                            if observation_writer
                            else None
                        ),
                    )
                    read_pcap(
                        capture_path,
                        on_packet,
                        keylog_path=config.keylog_path,
                    )
            except Exception:
                LOGGER.exception("Rolling pcap re-process failed")
                continue
            try:
                writer.flush_once()
            except Exception:
                LOGGER.exception("CBOM flush failed")
    finally:
        _stop_background_capture(capture_proc)
        try:
            writer.flush_once()
        except Exception:
            LOGGER.exception("Final CBOM flush failed")
