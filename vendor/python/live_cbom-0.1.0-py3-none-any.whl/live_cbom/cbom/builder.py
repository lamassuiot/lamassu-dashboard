from __future__ import annotations

import json
import re
from typing import Any

from live_cbom.cbom.registry import CryptoRegistry
from live_cbom.cbom import taxonomy
from live_cbom.cbom.taxonomy import AlgorithmSpec
from live_cbom.config import Config


def _cn_from_subject(subject: str) -> str:
    """Extract the Common Name from an RFC 4514 subject string, e.g.
    "CN=*.github.com,O=GitHub,C=US" -> "*.github.com"."""
    if not subject:
        return ""
    match = re.search(r"CN=([^,]+)", subject)
    return match.group(1).strip() if match else ""


def _register_dependency(bom: Any, source: Any, destination: Any) -> None:
    try:
        bom.register_dependency(source=source, destination=destination)
        return
    except TypeError:
        pass

    try:
        bom.register_dependency(source, [destination])
        return
    except TypeError:
        pass

    bom.register_dependency(source, destination)


def _add_property(target: Any, name: str, value: str, property_cls: Any) -> None:
    prop = property_cls(name=name, value=value)
    props = getattr(target, "properties", None)
    if props is None:
        target.properties = [prop]
        return
    if hasattr(props, "add"):
        props.add(prop)
        return
    props.append(prop)


def _add_warning_property(component: Any, warning: str, property_cls: Any) -> None:
    _add_property(component, "live-cbom:warning", warning, property_cls)


def _add_set_property(target: Any, name: str, values: set[str], property_cls: Any) -> None:
    if not values:
        return
    _add_property(target, name, json.dumps(sorted(values)), property_cls)


def _add_list_property(target: Any, name: str, values: list[str], property_cls: Any) -> None:
    if not values:
        return
    _add_property(target, name, json.dumps(values), property_cls)


def build_bom(registry: CryptoRegistry, config: Config):  # type: ignore[no-untyped-def]
    from cyclonedx.model import Property
    from cyclonedx.model.bom import Bom
    from cyclonedx.model.component import Component, ComponentType
    from cyclonedx.model.crypto import (
        AlgorithmProperties,
        CertificateProperties,
        CryptoAssetType,
        CryptoFunction,
        CryptoMode,
        CryptoPrimitive,
        CryptoProperties,
        ProtocolProperties,
        ProtocolPropertiesCipherSuite,
        ProtocolPropertiesType,
    )
    from cyclonedx.model.contact import OrganizationalEntity
    from cyclonedx.model.service import Service
    from cyclonedx.model.tool import ToolRepository

    _PRIMITIVES = {
        "ae": CryptoPrimitive.AE,
        "blockcipher": CryptoPrimitive.BLOCK_CIPHER,
        "streamcipher": CryptoPrimitive.STREAM_CIPHER,
        "hash": CryptoPrimitive.HASH,
        "mac": CryptoPrimitive.MAC,
        "key-agree": CryptoPrimitive.KEY_AGREE,
        "kem": CryptoPrimitive.KEM,
        "combiner": CryptoPrimitive.COMBINER,
        "signature": CryptoPrimitive.SIGNATURE,
        "pke": CryptoPrimitive.PKE,
        "kdf": CryptoPrimitive.KDF,
    }
    _FUNCTIONS = {
        "encrypt": CryptoFunction.ENCRYPT,
        "decrypt": CryptoFunction.DECRYPT,
        "tag": CryptoFunction.TAG,
        "digest": CryptoFunction.DIGEST,
        "keygen": CryptoFunction.KEYGEN,
        "encapsulate": CryptoFunction.ENCAPSULATE,
        "decapsulate": CryptoFunction.DECAPSULATE,
        "sign": CryptoFunction.SIGN,
        "verify": CryptoFunction.VERIFY,
        "keyderive": CryptoFunction.KEYDERIVE,
        "generate": CryptoFunction.GENERATE,
    }
    _MODES = {"gcm": CryptoMode.GCM, "cbc": CryptoMode.CBC, "ccm": CryptoMode.CCM}

    protocols, certificates, services, _ = registry.snapshot()
    bom = Bom()
    root_component = Component(
        name=config.bom_component_name,
        version=config.bom_component_version,
        type=ComponentType.APPLICATION,
    )
    bom.metadata.component = root_component

    live_capture_service = Service(
        name="LiveCapture",
        provider=OrganizationalEntity(name="Ikerlan_LKS"),
    )
    bom.metadata.tools = ToolRepository(services=[live_capture_service])

    algorithm_components: dict[str, Any] = {}
    protocol_components: dict[str, Any] = {}
    certificate_components: dict[str, Any] = {}
    service_components: dict[str, Any] = {}

    def get_algorithm(spec: AlgorithmSpec) -> Any:
        """Create (once) and return the CycloneDX component for an AlgorithmSpec."""
        existing = algorithm_components.get(spec.key)
        if existing is not None:
            return existing

        algo_kwargs: dict[str, Any] = {}
        primitive = _PRIMITIVES.get(spec.primitive)
        if primitive is not None:
            algo_kwargs["primitive"] = primitive
        if spec.param_set:
            algo_kwargs["parameter_set_identifier"] = spec.param_set
        mode = _MODES.get(spec.mode)
        if mode is not None:
            algo_kwargs["mode"] = mode
        if spec.curve:
            algo_kwargs["curve"] = spec.curve
        functions = [self_fn for self_fn in (_FUNCTIONS.get(t) for t in spec.crypto_functions) if self_fn]
        if functions:
            algo_kwargs["crypto_functions"] = functions
        if spec.classical_security_level is not None:
            algo_kwargs["classical_security_level"] = spec.classical_security_level
        if spec.nist_quantum_security_level is not None:
            algo_kwargs["nist_quantum_security_level"] = spec.nist_quantum_security_level

        crypto_props_kwargs: dict[str, Any] = {
            "asset_type": CryptoAssetType.ALGORITHM,
            "algorithm_properties": AlgorithmProperties(**algo_kwargs),
        }
        if spec.oid:
            crypto_props_kwargs["oid"] = spec.oid

        component = Component(
            bom_ref=spec.key,
            type=ComponentType.CRYPTOGRAPHIC_ASSET,
            name=spec.name,
            crypto_properties=CryptoProperties(**crypto_props_kwargs),
        )
        bom.components.add(component)
        algorithm_components[spec.key] = component
        return component

    def specs_for_group(group_name: str) -> list[AlgorithmSpec]:
        return taxonomy.decompose_named_group(group_name)

    # ----------------------------------------------------------------------- #
    # Certificates — built first so protocols can reference them.
    # related_crypto_refs holds the protocol bom-refs this cert was seen on.
    # ----------------------------------------------------------------------- #
    protocol_ref_to_cert_refs: dict[str, list[str]] = {}
    # Server-asserted hostname (cert CN) per protocol, used as a serverName fallback
    # when the client did not send SNI.
    protocol_ref_to_cert_cn: dict[str, str] = {}

    for key, cert in certificates.items():
        cert_props_kwargs: dict[str, Any] = {
            "subject_name": cert.info.subject,
            "issuer_name": cert.info.issuer,
            "certificate_format": "X.509",
        }
        if cert.info.not_before is not None:
            cert_props_kwargs["not_valid_before"] = cert.info.not_before
        if cert.info.not_after is not None:
            cert_props_kwargs["not_valid_after"] = cert.info.not_after

        # subjectPublicKeyRef -> the cert's public-key algorithm asset.
        pubkey_spec = taxonomy.public_key_spec(cert.info.public_key_type, cert.info.public_key_size)
        pubkey_component = get_algorithm(pubkey_spec) if pubkey_spec else None
        if pubkey_component is not None:
            cert_props_kwargs["subject_public_key_ref"] = pubkey_component.bom_ref

        # signatureAlgorithmRef -> the issuer-signature algorithm asset.
        sig_spec = taxonomy.cert_signature_spec(cert.info.sig_algorithm)
        sig_component = get_algorithm(sig_spec) if sig_spec else None
        if sig_component is not None:
            cert_props_kwargs["signature_algorithm_ref"] = sig_component.bom_ref

        try:
            cert_props = CertificateProperties(**cert_props_kwargs)
        except TypeError:
            cert_props_kwargs.pop("subject_public_key_ref", None)
            cert_props_kwargs.pop("signature_algorithm_ref", None)
            cert_props = CertificateProperties(**cert_props_kwargs)

        cert_component = Component(
            bom_ref=cert.bom_ref,
            type=ComponentType.CRYPTOGRAPHIC_ASSET,
            name=cert.info.subject,
            crypto_properties=CryptoProperties(
                asset_type=CryptoAssetType.CERTIFICATE,
                certificate_properties=cert_props,
            ),
        )
        for warning in cert.warnings:
            _add_warning_property(cert_component, warning, Property)
        _add_property(cert_component, "live-cbom:pem", cert.info.pem, Property)
        if cert.roles:
            _add_property(cert_component, "live-cbom:tls.certificateRole", ",".join(sorted(cert.roles)), Property)
        bom.components.add(cert_component)
        certificate_components[key] = cert_component

        # Certificate depends on its public-key and signature algorithm assets.
        if pubkey_component is not None:
            _register_dependency(bom, cert_component, pubkey_component)
        if sig_component is not None:
            _register_dependency(bom, cert_component, sig_component)

        cert_cn = _cn_from_subject(cert.info.subject)
        for protocol_ref in cert.related_crypto_refs:
            protocol_ref_to_cert_refs.setdefault(protocol_ref, []).append(cert.bom_ref)
            if cert_cn:
                protocol_ref_to_cert_cn.setdefault(protocol_ref, cert_cn)

    # ----------------------------------------------------------------------- #
    # Certificate chain linking — connect a certificate to its issuer's own
    # certificate component, when that issuer cert was also observed (e.g. an
    # intermediate CA sent alongside the leaf in the same handshake). Matching
    # is by subject/issuer distinguished name across the whole registry, not
    # just within one connection, since certificates are already deduplicated
    # globally by (issuer, subject) — a CA observed via one connection's chain
    # is the same CertEntry referenced by every leaf that chains to it.
    # `certificateProperties.relatedCryptographicAssets` (the CycloneDX 1.7
    # replacement for this) isn't yet implemented by cyclonedx-python-lib, so
    # the link is expressed via the BOM dependency graph (as with cert -> key
    # / cert -> signature-algorithm above) plus a readable property.
    # ----------------------------------------------------------------------- #
    subject_to_cert_component: dict[str, Any] = {}
    for key, cert in certificates.items():
        subject_to_cert_component.setdefault(cert.info.subject, certificate_components[key])

    for key, cert in certificates.items():
        if not cert.info.issuer or cert.info.issuer == cert.info.subject:
            continue
        issuer_component = subject_to_cert_component.get(cert.info.issuer)
        if issuer_component is None:
            continue
        cert_component = certificate_components[key]
        _add_property(cert_component, "live-cbom:issuerCertificateRef", str(issuer_component.bom_ref), Property)
        _register_dependency(bom, cert_component, issuer_component)

    # ----------------------------------------------------------------------- #
    # Protocols
    # ----------------------------------------------------------------------- #
    for key, protocol in protocols.items():
        # Union of offered (client) suites + negotiated (server) suite.
        all_cipher_hexes: dict[str, str] = dict(protocol.offered_cipher_hexes)
        if protocol.cipher_hex and protocol.cipher_name:
            all_cipher_hexes.setdefault(protocol.cipher_hex, protocol.cipher_name)

        cipher_suite_objects: list[Any] = []
        negotiated_algo_refs: list[str] = []  # symmetric + hash of the negotiated suite

        for hex_val, cs_name in sorted(all_cipher_hexes.items(), key=lambda x: x[1]):
            is_negotiated = hex_val == protocol.cipher_hex
            suite_bom_refs: list[str] = []
            for spec in taxonomy.decompose_cipher_suite(cs_name):
                get_algorithm(spec)
                suite_bom_refs.append(spec.key)
                if is_negotiated:
                    negotiated_algo_refs.append(spec.key)

            # One 2-byte IANA codepoint, e.g. "0x1301" — never split per byte
            # (a SortedSet would reorder the bytes and destroy the codepoint).
            identifiers = [hex_val]
            try:
                cs_obj = ProtocolPropertiesCipherSuite(
                    name=cs_name,
                    identifiers=identifiers,
                    algorithms=suite_bom_refs or None,
                )
            except Exception:
                cs_obj = ProtocolPropertiesCipherSuite(name=cs_name)
            cipher_suite_objects.append(cs_obj)

        if not cipher_suite_objects and protocol.cipher_name:
            cipher_suite_objects.append(ProtocolPropertiesCipherSuite(name=protocol.cipher_name))

        # ---- Negotiated key-exchange group -> decomposed assets + combiner ----
        group_algo_refs: list[str] = []
        combiner_pairs: list[tuple[str, tuple[str, ...]]] = []
        if protocol.negotiated_group:
            for spec in specs_for_group(protocol.negotiated_group):
                get_algorithm(spec)
                group_algo_refs.append(spec.key)
                if spec.components:
                    combiner_pairs.append((spec.key, spec.components))

        cert_refs = protocol_ref_to_cert_refs.get(protocol.bom_ref, [])

        # cryptoRefArray: everything that actually protected this session.
        crypto_refs: list[str] = []
        for ref in negotiated_algo_refs + group_algo_refs + cert_refs:
            if ref not in crypto_refs:
                crypto_refs.append(ref)

        protocol_props_kwargs: dict[str, Any] = {
            "type": ProtocolPropertiesType.TLS,
            "version": protocol.version,
            "cipher_suites": cipher_suite_objects,
        }
        if crypto_refs:
            protocol_props_kwargs["crypto_refs"] = crypto_refs

        try:
            protocol_props = ProtocolProperties(**protocol_props_kwargs)
        except TypeError:
            protocol_props_kwargs.pop("crypto_refs", None)
            protocol_props = ProtocolProperties(**protocol_props_kwargs)

        component = Component(
            bom_ref=protocol.bom_ref,
            type=ComponentType.CRYPTOGRAPHIC_ASSET,
            name="TLS",
            crypto_properties=CryptoProperties(
                asset_type=CryptoAssetType.PROTOCOL,
                protocol_properties=protocol_props,
            ),
        )

        # ---- Properties: offered vs negotiated, kept distinct ----
        _add_set_property(component, "live-cbom:tls.sni", protocol.sni_values, Property)

        # Network endpoint is always known (TCP/IP layer); record it so the protocol
        # component is self-contained, independent of the service-graph edge.
        if protocol.dst_ip:
            _add_property(
                component,
                "live-cbom:tls.endpoint",
                f"{protocol.dst_ip}:{protocol.dst_port}",
                Property,
            )

        # Resolve a display hostname WITHOUT faking provenance: client-asserted SNI
        # first, else server-asserted certificate CN (TLS <=1.2 only), else none.
        sni = next(iter(sorted(protocol.sni_values)), "")
        cert_cn = protocol_ref_to_cert_cn.get(protocol.bom_ref, "")
        if sni:
            server_name, server_name_source = sni, "sni"
        elif cert_cn:
            server_name, server_name_source = cert_cn, "certificate"
        else:
            server_name, server_name_source = "", "none"
        if server_name:
            _add_property(component, "live-cbom:tls.serverName", server_name, Property)
        _add_property(component, "live-cbom:tls.serverName.source", server_name_source, Property)

        if protocol.cipher_name:
            _add_property(component, "live-cbom:tls.negotiated.cipherSuite", protocol.cipher_name, Property)
        if protocol.negotiated_group:
            _add_property(component, "live-cbom:tls.negotiated.group", protocol.negotiated_group, Property)
        _add_set_property(component, "live-cbom:tls.offered.groups", protocol.supported_groups, Property)
        _add_list_property(component, "live-cbom:tls.offered.signatureAlgorithms", protocol.signature_algorithms, Property)
        _add_list_property(
            component,
            "live-cbom:tls.offered.certificateSignatureAlgorithms",
            protocol.certificate_signature_algorithms,
            Property,
        )
        _add_list_property(
            component,
            "live-cbom:tls.offered.keyShareGroups",
            protocol.key_share_groups,
            Property,
        )
        _add_list_property(
            component,
            "live-cbom:tls.offered.pskKeyExchangeModes",
            protocol.psk_key_exchange_modes,
            Property,
        )
        if protocol.server_handshake_signature_scheme:
            _add_property(
                component,
                "live-cbom:tls.server.handshakeSignatureScheme",
                protocol.server_handshake_signature_scheme,
                Property,
            )
        if protocol.client_handshake_signature_scheme:
            _add_property(
                component,
                "live-cbom:tls.client.handshakeSignatureScheme",
                protocol.client_handshake_signature_scheme,
                Property,
            )
        _add_set_property(component, "live-cbom:tls.client.supportedVersions", protocol.client_supported_versions, Property)
        if protocol.version:
            _add_property(component, "live-cbom:tls.server.selectedVersion", protocol.version, Property)
        # TLS 1.3 hides the certificate + CertificateVerify behind the handshake
        # encryption boundary. Whether that's actually unobservable depends on
        # whether a TLS key-log (e.g. from `ecapture tls -m keylog`) was even
        # in use for this run:
        #  - no keylog configured at all  -> structurally not observable passively.
        #  - keylog configured, still no cert -> decryption was attempted but
        #    didn't yield a certificate for this connection. That's a distinct,
        #    actionable state (wrong/missing secret for this process, session
        #    resumption skipping Certificate, or the record not yet re-processed)
        #    and must not be reported the same as "impossible to observe".
        if protocol.version == "1.3" and not cert_refs:
            visibility = protocol.server_authentication_status or (
                "not-decrypted"
                if config.has_keylog
                else "not-observed-passive"
            )
            _add_property(component, "live-cbom:tls.auth.visibility", visibility, Property)

        # mTLS: only surface these properties when the server actually asked
        # for a client certificate -- absent for the vast majority of
        # connections, so no point cluttering every protocol component.
        if protocol.mtls_requested:
            _add_property(component, "live-cbom:tls.mtls.requested", "true", Property)
            _add_list_property(
                component,
                "live-cbom:tls.clientAuth.acceptedSignatureAlgorithms",
                protocol.client_auth_signature_algorithms,
                Property,
            )
            _add_list_property(
                component,
                "live-cbom:tls.clientAuth.acceptedCertificateSignatureAlgorithms",
                protocol.client_auth_certificate_signature_algorithms,
                Property,
            )
            _add_property(
                component,
                "live-cbom:tls.mtls.clientCertPresented",
                "true" if protocol.mtls_client_cert_presented else "false",
                Property,
            )

        for warning in protocol.warnings:
            _add_warning_property(component, warning, Property)

        bom.components.add(component)
        protocol_components[key] = component

        # ---- Dependency graph ----
        seen_dep: set[str] = set()
        for ref in crypto_refs:
            algo_comp = algorithm_components.get(ref)
            target = algo_comp if algo_comp is not None else _find_component_by_ref(certificate_components, ref)
            if target is not None and ref not in seen_dep:
                seen_dep.add(ref)
                _register_dependency(bom, component, target)
        # Combiner asset declares the two halves it is built from.
        for combiner_ref, half_refs in combiner_pairs:
            combiner_comp = algorithm_components.get(combiner_ref)
            for half in half_refs:
                half_comp = algorithm_components.get(half)
                if combiner_comp is not None and half_comp is not None:
                    _register_dependency(bom, combiner_comp, half_comp)

    # ----------------------------------------------------------------------- #
    # Services -> protocol dependencies
    # ----------------------------------------------------------------------- #
    for service_key, service in services.items():
        svc = Service(name=service_key)
        bom.services.add(svc)
        service_components[service_key] = svc
        for crypto_ref in service.crypto_refs:
            for protocol_component in protocol_components.values():
                if str(getattr(protocol_component, "bom_ref", "")) == str(crypto_ref):
                    _register_dependency(bom, svc, protocol_component)

    try:
        from cyclonedx.model.composition import AggregateType, Composition  # type: ignore

        bom.compositions.add(
            Composition(
                aggregate=AggregateType.INCOMPLETE,
                assemblies=[getattr(root_component, "bom_ref", config.bom_component_name)],
            )
        )
    except Exception:
        pass
    return bom


def _find_component_by_ref(components: dict[str, Any], ref: str) -> Any:
    for comp in components.values():
        if str(getattr(comp, "bom_ref", "")) == str(ref):
            return comp
    return None
