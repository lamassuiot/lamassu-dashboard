"""Algorithm taxonomy: decompose TLS cipher suites, named groups and X.509
algorithm identifiers into concrete cryptographic-asset primitives.

The module is deliberately format-neutral: it returns :class:`AlgorithmSpec`
records (plain data) and never imports cyclonedx. The CBOM builder maps the
``primitive`` / ``crypto_functions`` / ``mode`` string tokens onto the
corresponding cyclonedx enums.

Each spec carries a stable ``key`` that doubles as its CycloneDX ``bom-ref``,
so identical algorithm identities collapse to a single component regardless of
how many suites or connections reference them.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class AlgorithmSpec:
    key: str  # stable dedupe key == CycloneDX bom-ref, e.g. "crypto:alg:aes-128-gcm"
    name: str
    primitive: str  # token: ae|blockcipher|streamcipher|hash|mac|key-agree|kem|combiner|signature|pke
    family: str = ""
    param_set: str = ""
    mode: str = ""  # gcm|cbc|ccm
    curve: str = ""
    oid: str = ""
    crypto_functions: tuple[str, ...] = ()
    classical_security_level: int | None = None
    nist_quantum_security_level: int | None = None
    # For combiner assets: bom-ref keys of the sub-algorithms it composes.
    components: tuple[str, ...] = field(default_factory=tuple)


# --------------------------------------------------------------------------- #
# Concrete algorithm catalogue
# --------------------------------------------------------------------------- #

# Hashes (PRF / HKDF / HMAC underlying digest)
_SHA256 = AlgorithmSpec("crypto:alg:sha-256", "SHA-256", "hash", "SHA-2", "256",
                        oid="2.16.840.1.101.3.4.2.1", crypto_functions=("digest",),
                        classical_security_level=128, nist_quantum_security_level=1)
_SHA384 = AlgorithmSpec("crypto:alg:sha-384", "SHA-384", "hash", "SHA-2", "384",
                        oid="2.16.840.1.101.3.4.2.2", crypto_functions=("digest",),
                        classical_security_level=192, nist_quantum_security_level=2)
_SHA512 = AlgorithmSpec("crypto:alg:sha-512", "SHA-512", "hash", "SHA-2", "512",
                        oid="2.16.840.1.101.3.4.2.3", crypto_functions=("digest",),
                        classical_security_level=256, nist_quantum_security_level=2)
_SHA1 = AlgorithmSpec("crypto:alg:sha-1", "SHA-1", "hash", "SHA-1",
                      oid="1.3.14.3.2.26", crypto_functions=("digest",),
                      classical_security_level=0, nist_quantum_security_level=0)
_MD5 = AlgorithmSpec("crypto:alg:md5", "MD5", "hash", "MD5",
                     oid="1.2.840.113549.2.5", crypto_functions=("digest",),
                     classical_security_level=0, nist_quantum_security_level=0)

# HMAC (integrity for CBC suites; integrity comes from a separate MAC, not the AEAD)
_HMAC_SHA1 = AlgorithmSpec("crypto:alg:hmac-sha1", "HMAC-SHA-1", "mac", "HMAC",
                           crypto_functions=("tag",))
_HMAC_SHA256 = AlgorithmSpec("crypto:alg:hmac-sha256", "HMAC-SHA-256", "mac", "HMAC",
                             crypto_functions=("tag",))
_HMAC_SHA384 = AlgorithmSpec("crypto:alg:hmac-sha384", "HMAC-SHA-384", "mac", "HMAC",
                             crypto_functions=("tag",))
_HMAC_MD5 = AlgorithmSpec("crypto:alg:hmac-md5", "HMAC-MD5", "mac", "HMAC",
                          crypto_functions=("tag",))

# Bulk ciphers / AEAD
_AES128GCM = AlgorithmSpec("crypto:alg:aes-128-gcm", "AES-128-GCM", "ae", "AES", "128",
                           mode="gcm", oid="2.16.840.1.101.3.4.1.6",
                           crypto_functions=("encrypt", "decrypt", "tag"),
                           classical_security_level=128, nist_quantum_security_level=1)
_AES256GCM = AlgorithmSpec("crypto:alg:aes-256-gcm", "AES-256-GCM", "ae", "AES", "256",
                           mode="gcm", oid="2.16.840.1.101.3.4.1.46",
                           crypto_functions=("encrypt", "decrypt", "tag"),
                           classical_security_level=256, nist_quantum_security_level=1)
_AES128CBC = AlgorithmSpec("crypto:alg:aes-128-cbc", "AES-128-CBC", "blockcipher", "AES", "128",
                           mode="cbc", oid="2.16.840.1.101.3.4.1.2",
                           crypto_functions=("encrypt", "decrypt"),
                           classical_security_level=128, nist_quantum_security_level=1)
_AES256CBC = AlgorithmSpec("crypto:alg:aes-256-cbc", "AES-256-CBC", "blockcipher", "AES", "256",
                           mode="cbc", oid="2.16.840.1.101.3.4.1.42",
                           crypto_functions=("encrypt", "decrypt"),
                           classical_security_level=256, nist_quantum_security_level=1)
_CHACHA = AlgorithmSpec("crypto:alg:chacha20-poly1305", "ChaCha20-Poly1305", "ae",
                        "ChaCha20-Poly1305", "256",
                        crypto_functions=("encrypt", "decrypt", "tag"),
                        classical_security_level=256, nist_quantum_security_level=1)
_3DES = AlgorithmSpec("crypto:alg:3des-cbc", "3DES-CBC", "blockcipher", "3DES", "168",
                      mode="cbc", oid="1.2.840.113549.3.7",
                      crypto_functions=("encrypt", "decrypt"),
                      classical_security_level=112, nist_quantum_security_level=0)
_RC4 = AlgorithmSpec("crypto:alg:rc4", "RC4", "streamcipher", "RC4", "128",
                     crypto_functions=("encrypt", "decrypt"),
                     classical_security_level=0, nist_quantum_security_level=0)

# Key-exchange / KEM primitives
_DHE = AlgorithmSpec("crypto:alg:dhe", "DHE", "key-agree", "DH",
                     crypto_functions=("keygen",),
                     classical_security_level=112, nist_quantum_security_level=0)
_RSA_KT = AlgorithmSpec("crypto:alg:rsa-key-transport", "RSA", "pke", "RSA",
                        crypto_functions=("encrypt", "decrypt"),
                        classical_security_level=112, nist_quantum_security_level=0)

# Authentication (signature) families derived from the suite name
_SIG_RSA = AlgorithmSpec("crypto:alg:rsa-signature", "RSA", "signature", "RSA",
                         crypto_functions=("sign", "verify"),
                         classical_security_level=112, nist_quantum_security_level=0)
_SIG_ECDSA = AlgorithmSpec("crypto:alg:ecdsa-signature", "ECDSA", "signature", "ECDSA",
                           crypto_functions=("sign", "verify"),
                           classical_security_level=128, nist_quantum_security_level=0)
_SIG_DSA = AlgorithmSpec("crypto:alg:dsa-signature", "DSA", "signature", "DSA",
                         crypto_functions=("sign", "verify"),
                         classical_security_level=112, nist_quantum_security_level=0)

# ML-KEM (post-quantum KEM)
_MLKEM512 = AlgorithmSpec("crypto:alg:ml-kem-512", "ML-KEM-512", "kem", "ML-KEM", "512",
                          oid="2.16.840.1.101.3.4.4.1",
                          crypto_functions=("keygen", "encapsulate", "decapsulate"),
                          nist_quantum_security_level=1)
_MLKEM768 = AlgorithmSpec("crypto:alg:ml-kem-768", "ML-KEM-768", "kem", "ML-KEM", "768",
                          oid="2.16.840.1.101.3.4.4.2",
                          crypto_functions=("keygen", "encapsulate", "decapsulate"),
                          nist_quantum_security_level=3)
_MLKEM1024 = AlgorithmSpec("crypto:alg:ml-kem-1024", "ML-KEM-1024", "kem", "ML-KEM", "1024",
                           oid="2.16.840.1.101.3.4.4.3",
                           crypto_functions=("keygen", "encapsulate", "decapsulate"),
                           nist_quantum_security_level=5)


def _ecdhe_spec(curve: str) -> AlgorithmSpec:
    """ECDHE key-agreement asset for a named curve (e.g. secp256r1, curve25519)."""
    classical = {"secp256r1": 128, "curve25519": 128, "secp384r1": 192,
                 "x448": 224, "secp521r1": 256}.get(curve, 128)
    return AlgorithmSpec(
        key=f"crypto:alg:ecdhe-{curve}", name="ECDHE", primitive="key-agree",
        family="ECDH", curve=curve, crypto_functions=("keygen",),
        classical_security_level=classical, nist_quantum_security_level=0,
    )


def _x25519_spec() -> AlgorithmSpec:
    return AlgorithmSpec(
        key="crypto:alg:x25519", name="X25519", primitive="key-agree", family="ECDH",
        curve="curve25519", crypto_functions=("keygen",),
        classical_security_level=128, nist_quantum_security_level=0,
    )


# Named TLS group -> classical curve label for ECDHE decomposition.
_GROUP_CURVES = {
    "secp256r1": "secp256r1", "secp384r1": "secp384r1", "secp521r1": "secp521r1",
    "secp224r1": "secp224r1", "secp192r1": "secp192r1",
}

# Hybrid PQC groups -> (classical half spec factory, ML-KEM half spec, combiner pq level).
_HYBRID_GROUPS: dict[str, tuple[AlgorithmSpec, AlgorithmSpec, int]] = {
    "X25519MLKEM768": (_x25519_spec(), _MLKEM768, 3),
    "SecP256r1MLKEM768": (_ecdhe_spec("secp256r1"), _MLKEM768, 3),
    "SecP384r1MLKEM1024": (_ecdhe_spec("secp384r1"), _MLKEM1024, 5),
    "X25519Kyber768Draft00": (_x25519_spec(), _MLKEM768, 3),
    "SecP256r1Kyber768Draft00": (_ecdhe_spec("secp256r1"), _MLKEM768, 3),
}

_PURE_MLKEM_GROUPS = {"mlkem512": _MLKEM512, "mlkem768": _MLKEM768, "mlkem1024": _MLKEM1024}


# --------------------------------------------------------------------------- #
# Cipher-suite decomposition
# --------------------------------------------------------------------------- #

def _bulk_cipher_spec(upper: str) -> AlgorithmSpec | None:
    if "AES_256_GCM" in upper or "AES-256-GCM" in upper:
        return _AES256GCM
    if "AES_128_GCM" in upper or "AES-128-GCM" in upper:
        return _AES128GCM
    if "AES_256_CBC" in upper or "AES-256-CBC" in upper:
        return _AES256CBC
    if "AES_128_CBC" in upper or "AES-128-CBC" in upper:
        return _AES128CBC
    if "CHACHA20_POLY1305" in upper or "CHACHA20-POLY1305" in upper:
        return _CHACHA
    if "3DES" in upper:
        return _3DES
    if "RC4" in upper:
        return _RC4
    return None


def _suite_hash_specs(upper: str, is_cbc: bool) -> list[AlgorithmSpec]:
    """Hash (PRF/HKDF) and, for CBC suites, the HMAC integrity asset."""
    if upper.endswith("_SHA384") or upper.endswith("SHA384"):
        return [_SHA384] + ([_HMAC_SHA384] if is_cbc else [])
    if upper.endswith("_SHA256") or upper.endswith("SHA256"):
        return [_SHA256] + ([_HMAC_SHA256] if is_cbc else [])
    if upper.endswith("_SHA") or upper.endswith("_SHA1"):
        # Legacy CBC suites: integrity is HMAC-SHA1 over the SHA-1 digest.
        return [_SHA1] + ([_HMAC_SHA1] if is_cbc else [])
    if upper.endswith("_MD5"):
        return [_MD5] + ([_HMAC_MD5] if is_cbc else [])
    return []


def decompose_cipher_suite(name: str) -> list[AlgorithmSpec]:
    """Decompose a TLS cipher-suite name into its constituent algorithm specs.

    TLS 1.3 suites yield {AEAD, HKDF-hash}. TLS 1.2 suites yield up to four
    facets: key-exchange family, authentication (signature) family, bulk cipher
    (+ mode), and MAC/PRF hash. CBC suites additionally yield a distinct HMAC
    asset because their integrity is *not* authenticated encryption.
    """
    if not name:
        return []
    upper = name.upper()
    specs: list[AlgorithmSpec] = []
    seen: set[str] = set()

    def add(spec: AlgorithmSpec | None) -> None:
        if spec is not None and spec.key not in seen:
            seen.add(spec.key)
            specs.append(spec)

    bulk = _bulk_cipher_spec(upper)
    is_cbc = bulk is not None and bulk.mode == "cbc"

    is_tls13 = upper.startswith("TLS_AES_") or upper.startswith("TLS_CHACHA20_POLY1305_SHA")

    if not is_tls13 and upper.startswith("TLS_"):
        # <= TLS 1.2: the suite name encodes KEX + auth families.
        if "ECDHE_ECDSA" in upper:
            add(_ecdhe_spec("secp256r1")); add(_SIG_ECDSA)
        elif "ECDHE_RSA" in upper:
            add(_ecdhe_spec("secp256r1")); add(_SIG_RSA)
        elif "DHE_RSA" in upper:
            add(_DHE); add(_SIG_RSA)
        elif "DHE_DSS" in upper or "DHE_DSA" in upper:
            add(_DHE); add(_SIG_DSA)
        elif "ECDH_" in upper:
            add(_ecdhe_spec("secp256r1"))
        elif upper.startswith("TLS_RSA_WITH_") or "_RSA_WITH_" in upper and "DHE" not in upper:
            # Static-RSA key transport: authentication is implicit (no signature
            # on the wire); RSA-as-pke is the correct single facet here.
            add(_RSA_KT)

    add(bulk)
    for hspec in _suite_hash_specs(upper, is_cbc):
        add(hspec)
    return specs


# --------------------------------------------------------------------------- #
# Named-group decomposition
# --------------------------------------------------------------------------- #

def decompose_named_group(name: str) -> list[AlgorithmSpec]:
    """Decompose a TLS named group into algorithm specs.

    Classical groups yield a single key-agreement asset. Hybrid PQC groups yield
    three assets: the classical half (key-agree), the ML-KEM half (kem), and a
    ``combiner`` asset whose ``components`` reference the two halves. Pure
    ML-KEM groups yield a single kem asset.
    """
    if not name:
        return []

    if name in _HYBRID_GROUPS:
        classical, kem, pq_level = _HYBRID_GROUPS[name]
        family = "Hybrid-KEM"
        combiner = AlgorithmSpec(
            key=f"crypto:alg:{name.lower()}", name=name, primitive="combiner",
            family=family, nist_quantum_security_level=pq_level,
            components=(classical.key, kem.key),
        )
        return [classical, kem, combiner]

    if name in _PURE_MLKEM_GROUPS:
        return [_PURE_MLKEM_GROUPS[name]]

    if name == "x25519":
        return [_x25519_spec()]
    if name == "x448":
        return [AlgorithmSpec("crypto:alg:x448", "X448", "key-agree", "ECDH",
                              curve="curve448", crypto_functions=("keygen",),
                              classical_security_level=224, nist_quantum_security_level=0)]
    if name in _GROUP_CURVES:
        return [_ecdhe_spec(_GROUP_CURVES[name])]
    if name.startswith("ffdhe"):
        bits = name.replace("ffdhe", "") or ""
        return [AlgorithmSpec(f"crypto:alg:dhe-{name}", "DHE", "key-agree", "FFDHE",
                              param_set=bits, crypto_functions=("keygen",),
                              classical_security_level=112, nist_quantum_security_level=0)]
    return []


# --------------------------------------------------------------------------- #
# X.509 certificate decomposition
# --------------------------------------------------------------------------- #

def public_key_spec(key_type: str, key_size: int) -> AlgorithmSpec | None:
    """Algorithm asset for a certificate's SubjectPublicKeyInfo."""
    kt = (key_type or "").upper()
    if kt == "RSA":
        ps = str(key_size) if key_size else ""
        classical = {1024: 80, 2048: 112, 3072: 128, 4096: 152}.get(key_size, 112)
        return AlgorithmSpec(
            key=f"crypto:alg:rsa-{ps}" if ps else "crypto:alg:rsa",
            name=f"RSA-{ps}" if ps else "RSA", primitive="pke", family="RSA",
            param_set=ps, oid="1.2.840.113549.1.1.1",
            classical_security_level=classical, nist_quantum_security_level=0,
        )
    if kt == "EC":
        return AlgorithmSpec(
            key="crypto:alg:ec-public-key", name="EC", primitive="signature",
            family="ECDSA", oid="1.2.840.10045.2.1",
            crypto_functions=("sign", "verify"),
            classical_security_level=128, nist_quantum_security_level=0,
        )
    if kt == "ED25519":
        return AlgorithmSpec(
            key="crypto:alg:ed25519", name="Ed25519", primitive="signature",
            family="EdDSA", curve="curve25519", oid="1.3.101.112",
            crypto_functions=("sign", "verify"),
            classical_security_level=128, nist_quantum_security_level=0,
        )
    if kt == "ED448":
        return AlgorithmSpec(
            key="crypto:alg:ed448", name="Ed448", primitive="signature",
            family="EdDSA", curve="curve448", oid="1.3.101.113",
            crypto_functions=("sign", "verify"),
            classical_security_level=224, nist_quantum_security_level=0,
        )
    if kt == "DSA":
        return AlgorithmSpec(
            key="crypto:alg:dsa-public-key", name="DSA", primitive="signature",
            family="DSA", crypto_functions=("sign", "verify"),
            classical_security_level=112, nist_quantum_security_level=0,
        )
    return None


# X.509 signatureAlgorithm OID name (cryptography lib `_name`) -> signature asset.
_CERT_SIG_SPECS: dict[str, AlgorithmSpec] = {
    "sha256WithRSAEncryption": AlgorithmSpec(
        "crypto:alg:rsassa-pkcs1-sha256", "RSASSA-PKCS1-v1_5-SHA-256", "signature",
        "RSASSA-PKCS1", oid="1.2.840.113549.1.1.11",
        crypto_functions=("sign", "verify"), nist_quantum_security_level=0),
    "sha384WithRSAEncryption": AlgorithmSpec(
        "crypto:alg:rsassa-pkcs1-sha384", "RSASSA-PKCS1-v1_5-SHA-384", "signature",
        "RSASSA-PKCS1", oid="1.2.840.113549.1.1.12",
        crypto_functions=("sign", "verify"), nist_quantum_security_level=0),
    "sha512WithRSAEncryption": AlgorithmSpec(
        "crypto:alg:rsassa-pkcs1-sha512", "RSASSA-PKCS1-v1_5-SHA-512", "signature",
        "RSASSA-PKCS1", oid="1.2.840.113549.1.1.13",
        crypto_functions=("sign", "verify"), nist_quantum_security_level=0),
    "sha1WithRSAEncryption": AlgorithmSpec(
        "crypto:alg:rsassa-pkcs1-sha1", "RSASSA-PKCS1-v1_5-SHA-1", "signature",
        "RSASSA-PKCS1", oid="1.2.840.113549.1.1.5",
        crypto_functions=("sign", "verify"), nist_quantum_security_level=0),
    "rsassaPss": AlgorithmSpec(
        "crypto:alg:rsassa-pss", "RSASSA-PSS", "signature", "RSASSA-PSS",
        oid="1.2.840.113549.1.1.10",
        crypto_functions=("sign", "verify"), nist_quantum_security_level=0),
    "ecdsa-with-SHA256": AlgorithmSpec(
        "crypto:alg:ecdsa-sha256", "ECDSA-SHA-256", "signature", "ECDSA",
        oid="1.2.840.10045.4.3.2",
        crypto_functions=("sign", "verify"),
        classical_security_level=128, nist_quantum_security_level=0),
    "ecdsa-with-SHA384": AlgorithmSpec(
        "crypto:alg:ecdsa-sha384", "ECDSA-SHA-384", "signature", "ECDSA",
        oid="1.2.840.10045.4.3.3",
        crypto_functions=("sign", "verify"),
        classical_security_level=192, nist_quantum_security_level=0),
    "ecdsa-with-SHA512": AlgorithmSpec(
        "crypto:alg:ecdsa-sha512", "ECDSA-SHA-512", "signature", "ECDSA",
        oid="1.2.840.10045.4.3.4",
        crypto_functions=("sign", "verify"),
        classical_security_level=256, nist_quantum_security_level=0),
    "ed25519": AlgorithmSpec(
        "crypto:alg:ed25519", "Ed25519", "signature", "EdDSA", curve="curve25519",
        oid="1.3.101.112", crypto_functions=("sign", "verify"),
        classical_security_level=128, nist_quantum_security_level=0),
    "ed448": AlgorithmSpec(
        "crypto:alg:ed448", "Ed448", "signature", "EdDSA", curve="curve448",
        oid="1.3.101.113", crypto_functions=("sign", "verify"),
        classical_security_level=224, nist_quantum_security_level=0),
}


def cert_signature_spec(sig_oid_name: str) -> AlgorithmSpec | None:
    """Algorithm asset for the issuer signature on a certificate."""
    if not sig_oid_name:
        return None
    spec = _CERT_SIG_SPECS.get(sig_oid_name)
    if spec is not None:
        return spec
    # Unknown OID name: emit a generic signature asset keyed by the name so it
    # still links rather than vanishing into a free-text property.
    slug = sig_oid_name.lower().replace(" ", "-")
    return AlgorithmSpec(
        key=f"crypto:alg:{slug}", name=sig_oid_name, primitive="signature",
        crypto_functions=("sign", "verify"), nist_quantum_security_level=0,
    )
