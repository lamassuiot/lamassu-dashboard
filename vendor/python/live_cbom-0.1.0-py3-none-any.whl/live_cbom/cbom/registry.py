from __future__ import annotations

import threading
import uuid
from collections.abc import Iterable
from dataclasses import dataclass, field

from live_cbom.extractors.certificates import CertInfo
from live_cbom.extractors.services import ServiceObservation, observe_service
from live_cbom.extractors.tls import TlsClientHelloInfo, TlsHandshakeInfo


def _new_bom_ref(prefix: str) -> str:
    return f"urn:live-cbom:{prefix}:{uuid.uuid4()}"


@dataclass
class ProtocolEntry:
    bom_ref: str
    version: str
    version_hex: str
    cipher_hex: str
    cipher_name: str
    src_ip: str
    dst_ip: str
    dst_port: int
    warnings: list[str] = field(default_factory=list)
    algorithm_bom_ref: str | None = None
    sni_values: set[str] = field(default_factory=set)
    client_offered_cipher_suites: set[str] = field(default_factory=set)
    server_negotiated_cipher_suites: set[str] = field(default_factory=set)
    client_supported_versions: set[str] = field(default_factory=set)
    server_supported_versions: set[str] = field(default_factory=set)
    # Hex→name map for client-offered suites (provides IANA identifiers for CBOM).
    offered_cipher_hexes: dict[str, str] = field(default_factory=dict)
    # TLS named groups the client advertised (supported_groups extension).
    supported_groups: set[str] = field(default_factory=set)
    # The single key-exchange group the server selected (ServerHello key_share).
    negotiated_group: str | None = None
    # Signature schemes advertised by the client (signature_algorithms).
    signature_algorithms: list[str] = field(default_factory=list)
    # mTLS: did the server send a CertificateRequest (asking the client to
    # authenticate with its own certificate)?
    mtls_requested: bool = False
    # mTLS: did the client actually present a non-empty certificate in
    # response? (A CertificateRequest with no client cert following it means
    # the client declined / had none configured.)
    mtls_client_cert_presented: bool = False


@dataclass
class CertEntry:
    bom_ref: str
    info: CertInfo
    warnings: list[str] = field(default_factory=list)
    related_crypto_refs: set[str] = field(default_factory=set)
    # Which side(s) of the handshake presented this certificate: "server",
    # "client", or both (e.g. if the same cert were reused in both roles
    # across different connections, though that would be unusual).
    roles: set[str] = field(default_factory=set)


class CryptoRegistry:
    @staticmethod
    def _extend_unique_ordered(target: list[str], values: Iterable[str]) -> None:
        seen = set(target)
        for value in values:
            if value in seen:
                continue
            seen.add(value)
            target.append(value)

    def __init__(self, compact: bool = False) -> None:
        """Initialise the registry.

        Args:
            compact: When ``True`` protocol entries are keyed by
                ``(TLS version, cipher suite)`` — all connections sharing the
                same cipher are merged into one CBOM component (original
                behaviour).  When ``False`` (default) each unique
                ``(version, cipher, sni-or-dst_ip, dst_port)`` tuple becomes
                its own component, giving one entry per observed connection.
        """
        self._lock = threading.Lock()
        self._compact = compact
        self.protocols: dict[str, ProtocolEntry] = {}
        self.certificates: dict[str, CertEntry] = {}
        self.services: dict[str, ServiceObservation] = {}
        self.algorithms: dict[str, str] = {}

    def _find_protocol_by_ref(self, bom_ref: str) -> ProtocolEntry | None:
        for entry in self.protocols.values():
            if entry.bom_ref == bom_ref:
                return entry
        return None

    @staticmethod
    def _merge_service_into_protocol(service: ServiceObservation, protocol: ProtocolEntry) -> None:
        protocol.sni_values.update(service.sni_values)
        protocol.client_offered_cipher_suites.update(service.client_offered_cipher_suites)
        protocol.server_negotiated_cipher_suites.update(service.server_negotiated_cipher_suites)
        protocol.client_supported_versions.update(service.client_supported_versions)
        protocol.server_supported_versions.update(service.server_supported_versions)
        protocol.offered_cipher_hexes.update(service.offered_cipher_hexes)
        protocol.supported_groups.update(service.supported_groups)
        if service.negotiated_group and not protocol.negotiated_group:
            protocol.negotiated_group = service.negotiated_group
        CryptoRegistry._extend_unique_ordered(protocol.signature_algorithms, service.signature_algorithms)

    def register_handshake(self, info: TlsHandshakeInfo, warnings: list[str] | None = None) -> ProtocolEntry:
        if self._compact:
            # Compact mode: group all connections with the same cipher together.
            key = f"{info.version_label}:{info.cipher_hex}"
        else:
            # Per-connection mode: use SNI (or dst IP) + port to keep each
            # connection as a separate protocol component.
            identity = info.sni if info.sni else info.dst_ip
            key = f"{info.version_label}:{info.cipher_hex}:{identity}:{info.dst_port}"
        with self._lock:
            entry = self.protocols.get(key)
            if entry is None:
                entry = ProtocolEntry(
                    bom_ref=_new_bom_ref("protocol"),
                    version=info.version_label,
                    version_hex=info.version_hex,
                    cipher_hex=info.cipher_hex,
                    cipher_name=info.cipher_name,
                    src_ip=info.src_ip,
                    dst_ip=info.dst_ip,
                    dst_port=info.dst_port,
                    warnings=list(warnings or []),
                )
                self.protocols[key] = entry
            else:
                entry.src_ip = info.src_ip
                entry.dst_ip = info.dst_ip
                entry.dst_port = info.dst_port
                if warnings:
                    for warning in warnings:
                        if warning not in entry.warnings:
                            entry.warnings.append(warning)
            service = observe_service(self.services, info.dst_ip, info.dst_port, entry.bom_ref)
            if info.sni:
                service.sni_values.add(info.sni)
            if info.cipher_name:
                service.server_negotiated_cipher_suites.add(info.cipher_name)
            if info.version_label:
                service.server_supported_versions.add(info.version_label)
            if info.sni:
                entry.sni_values.add(info.sni)
            if info.cipher_name:
                entry.server_negotiated_cipher_suites.add(info.cipher_name)
            if info.version_label:
                entry.server_supported_versions.add(info.version_label)
            # Track the negotiated cipher hex for identifier mapping.
            if info.cipher_hex and info.cipher_name:
                entry.offered_cipher_hexes.setdefault(info.cipher_hex, info.cipher_name)
                service.offered_cipher_hexes.setdefault(info.cipher_hex, info.cipher_name)
            # Key exchange group selected by the server (negotiated, not offered).
            if info.key_share_group:
                entry.negotiated_group = info.key_share_group
                service.negotiated_group = info.key_share_group
            self._merge_service_into_protocol(service, entry)
            return entry

    def register_client_hello(self, info: TlsClientHelloInfo) -> ServiceObservation:
        with self._lock:
            service = observe_service(self.services, info.dst_ip, info.dst_port)
            if info.sni:
                service.sni_values.add(info.sni)
            service.client_offered_cipher_suites.update(info.offered_cipher_names)
            service.client_supported_versions.update(info.supported_versions)
            # Build hex→name map for every offered cipher.
            for hex_val, name in zip(info.offered_cipher_hexes, info.offered_cipher_names):
                service.offered_cipher_hexes.setdefault(hex_val, name)
            # Named groups advertised by the client.
            service.supported_groups.update(info.supported_groups)
            self._extend_unique_ordered(service.signature_algorithms, info.signature_algorithms)
            for crypto_ref in service.crypto_refs:
                protocol = self._find_protocol_by_ref(crypto_ref)
                if protocol is not None:
                    self._merge_service_into_protocol(service, protocol)
            return service

    def register_algorithm(self, algorithm_key: str) -> str:
        with self._lock:
            ref = self.algorithms.get(algorithm_key)
            if ref is None:
                ref = _new_bom_ref("algorithm")
                self.algorithms[algorithm_key] = ref
            return ref

    def register_certificate(self, cert: CertInfo, warnings: list[str] | None = None) -> CertEntry:
        key = f"{cert.issuer}|{cert.subject}"
        with self._lock:
            entry = self.certificates.get(key)
            if entry is None:
                entry = CertEntry(
                    bom_ref=_new_bom_ref("certificate"),
                    info=cert,
                    warnings=list(warnings or []),
                )
                self.certificates[key] = entry
            elif warnings:
                for warning in warnings:
                    if warning not in entry.warnings:
                        entry.warnings.append(warning)
            return entry

    def link_service_to_crypto(self, dst_ip: str, dst_port: int, bom_ref: str) -> None:
        with self._lock:
            service = observe_service(self.services, dst_ip, dst_port, bom_ref)
            protocol = self._find_protocol_by_ref(bom_ref)
            if protocol is not None:
                self._merge_service_into_protocol(service, protocol)

    def link_certificate_to_crypto(self, cert_bom_ref: str, crypto_bom_ref: str, role: str | None = None) -> None:
        with self._lock:
            for cert_entry in self.certificates.values():
                if cert_entry.bom_ref == cert_bom_ref:
                    cert_entry.related_crypto_refs.add(crypto_bom_ref)
                    if role:
                        cert_entry.roles.add(role)
                    break
            if role == "client":
                protocol = self._find_protocol_by_ref(crypto_bom_ref)
                if protocol is not None:
                    protocol.mtls_client_cert_presented = True

    def mark_mtls_requested(self, dst_ip: str, dst_port: int) -> None:
        """Record that the server at dst_ip:dst_port sent a CertificateRequest
        (asking the client to authenticate with its own certificate)."""
        with self._lock:
            for entry in self.protocols.values():
                if entry.dst_ip == dst_ip and entry.dst_port == dst_port:
                    entry.mtls_requested = True

    def snapshot(self) -> tuple[dict[str, ProtocolEntry], dict[str, CertEntry], dict[str, ServiceObservation], dict[str, str]]:
        with self._lock:
            protocols = {
                k: ProtocolEntry(
                    bom_ref=v.bom_ref,
                    version=v.version,
                    version_hex=v.version_hex,
                    cipher_hex=v.cipher_hex,
                    cipher_name=v.cipher_name,
                    src_ip=v.src_ip,
                    dst_ip=v.dst_ip,
                    dst_port=v.dst_port,
                    warnings=list(v.warnings),
                    algorithm_bom_ref=v.algorithm_bom_ref,
                    sni_values=set(v.sni_values),
                    client_offered_cipher_suites=set(v.client_offered_cipher_suites),
                    server_negotiated_cipher_suites=set(v.server_negotiated_cipher_suites),
                    client_supported_versions=set(v.client_supported_versions),
                    server_supported_versions=set(v.server_supported_versions),
                    offered_cipher_hexes=dict(v.offered_cipher_hexes),
                    supported_groups=set(v.supported_groups),
                    negotiated_group=v.negotiated_group,
                    signature_algorithms=list(v.signature_algorithms),
                    mtls_requested=v.mtls_requested,
                    mtls_client_cert_presented=v.mtls_client_cert_presented,
                )
                for k, v in self.protocols.items()
            }
            certificates = {
                k: CertEntry(
                    bom_ref=v.bom_ref,
                    info=v.info,
                    warnings=list(v.warnings),
                    related_crypto_refs=set(v.related_crypto_refs),
                    roles=set(v.roles),
                )
                for k, v in self.certificates.items()
            }
            services = {
                k: ServiceObservation(
                    dst_ip=v.dst_ip,
                    dst_port=v.dst_port,
                    crypto_refs=set(v.crypto_refs),
                    sni_values=set(v.sni_values),
                    client_offered_cipher_suites=set(v.client_offered_cipher_suites),
                    server_negotiated_cipher_suites=set(v.server_negotiated_cipher_suites),
                    client_supported_versions=set(v.client_supported_versions),
                    server_supported_versions=set(v.server_supported_versions),
                    offered_cipher_hexes=dict(v.offered_cipher_hexes),
                    supported_groups=set(v.supported_groups),
                    negotiated_group=v.negotiated_group,
                    signature_algorithms=list(v.signature_algorithms),
                )
                for k, v in self.services.items()
            }
            algorithms = dict(self.algorithms)
            return protocols, certificates, services, algorithms
