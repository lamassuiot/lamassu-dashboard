from __future__ import annotations

DEPRECATED_TLS_VERSIONS = {"1.0", "1.1"}

DEPRECATED_CIPHERS = {
    "TLS_RSA_WITH_RC4_128_MD5",
    "TLS_RSA_WITH_RC4_128_SHA",
    "TLS_RSA_WITH_DES_CBC_SHA",
    "TLS_RSA_WITH_3DES_EDE_CBC_SHA",
}

WEAK_KEY_SIZES = {
    "RSA": 2048,
    "DSA": 2048,
    "EC": 224,
}


def get_warnings(
    version: str | None = None,
    cipher: str | None = None,
    key_type: str | None = None,
    key_size: int | None = None,
) -> list[str]:
    warnings: list[str] = []

    if version and version in DEPRECATED_TLS_VERSIONS:
        warnings.append(f"TLS {version} is deprecated (RFC 8996)")
    if cipher and cipher in DEPRECATED_CIPHERS:
        warnings.append(f"Cipher suite {cipher} is deprecated")
    if key_type and key_size:
        min_size = WEAK_KEY_SIZES.get(key_type.upper())
        if min_size and key_size < min_size:
            warnings.append(f"{key_type} key size {key_size} is weak; recommended minimum is {min_size}")
    return warnings
