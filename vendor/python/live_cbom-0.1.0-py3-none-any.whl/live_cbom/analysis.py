from __future__ import annotations

import logging
from collections.abc import Iterable, Mapping
from dataclasses import replace
from typing import Any

from live_cbom.cbom.registry import CryptoRegistry
from live_cbom.cbom.weak_crypto import get_warnings
from live_cbom.extractors.certificates import CertInfo
from live_cbom.extractors.tls import TlsClientHelloInfo
from live_cbom.observations import (
    DecodedObservation,
    decoded_observation_from_mapping,
)

LOGGER = logging.getLogger(__name__)

class ObservationProcessor:
    """Apply decoded observations to the CBOM registry.

    Packet decoding belongs in adapters (PyShark, Wiregasm, or another
    dissector). This class owns the shared domain behavior: connection
    tracking, warning generation, registry updates, certificate roles, and
    mTLS state.
    """

    def __init__(
        self,
        registry: CryptoRegistry,
        seen_connections: dict[str, bool] | None = None,
    ) -> None:
        self.registry = registry
        self.seen_connections = seen_connections if seen_connections is not None else {}
        self._client_hellos_by_stream: dict[str, TlsClientHelloInfo] = {}

    def ingest(self, observation: Mapping[str, Any]) -> None:
        """Validate and ingest one canonical Observation v1 mapping."""
        self._ingest_decoded(decoded_observation_from_mapping(observation))

    def _ingest_decoded(self, observation: DecodedObservation) -> None:
        self._track_connection(observation)

        if observation.client_hello is not None:
            self.registry.register_client_hello(observation.client_hello)
            if observation.stream_id:
                self._client_hellos_by_stream[observation.stream_id] = (
                    observation.client_hello
                )

        if observation.server_hello is not None:
            handshake = observation.server_hello
            client_hello = (
                self._client_hellos_by_stream.get(observation.stream_id)
                if observation.stream_id
                else None
            )
            if client_hello is not None and not handshake.sni:
                handshake = replace(handshake, sni=client_hello.sni)
            warnings = get_warnings(
                version=handshake.version_label,
                cipher=handshake.cipher_name,
            )
            protocol = self.registry.register_handshake(handshake, warnings=warnings)
            self.registry.link_service_to_crypto(
                handshake.dst_ip,
                handshake.dst_port,
                protocol.bom_ref,
            )

        if observation.certificates:
            LOGGER.info(
                "TLS certificate chain observed src=%s dst=%s chain_len=%s leaf_subject=%s",
                observation.src_ip or "-",
                observation.dst_ip or "-",
                len(observation.certificates),
                observation.certificates[0].subject,
            )
        for certificate in observation.certificates:
            self._register_certificate(certificate, observation)

        if (
            observation.certificate_requested
            and observation.src_ip
            and observation.src_port
        ):
            # CertificateRequest is sent by the server.
            self.registry.mark_mtls_requested(
                observation.src_ip,
                observation.src_port,
            )

    def ingest_many(
        self,
        observations: Iterable[Mapping[str, Any]],
    ) -> int:
        count = 0
        for observation in observations:
            self.ingest(observation)
            count += 1
        return count

    def _track_connection(self, observation: DecodedObservation) -> None:
        if observation.tcp_syn and observation.src_ip and observation.dst_ip:
            key = (
                f"{observation.src_ip}->{observation.dst_ip}:"
                f"{observation.dst_port}"
            )
            if key not in self.seen_connections:
                self.seen_connections[key] = False
                LOGGER.info(
                    "New TCP connection src=%s dst=%s:%s sni=- tls=- cipher=-",
                    observation.src_ip,
                    observation.dst_ip,
                    observation.dst_port,
                )

        tls = observation.tls_connection
        if tls is None:
            return
        key = f"{tls.src_ip}->{tls.dst_ip}:{tls.dst_port}"
        if key not in self.seen_connections:
            self.seen_connections[key] = True
            message = "New TLS connection"
        elif not self.seen_connections[key]:
            self.seen_connections[key] = True
            message = "TLS details"
        else:
            return
        LOGGER.info(
            "%s src=%s dst=%s:%s hello=%s sni=%s tls=%s cipher=%s",
            message,
            tls.src_ip,
            tls.dst_ip,
            tls.dst_port,
            tls.handshake_type,
            tls.sni or "-",
            tls.tls_version,
            tls.cipher_name,
        )

    def _register_certificate(
        self,
        certificate: CertInfo,
        observation: DecodedObservation,
    ) -> None:
        warnings = get_warnings(
            key_type=certificate.public_key_type,
            key_size=certificate.public_key_size,
        )
        cert_entry = self.registry.register_certificate(
            certificate,
            warnings=warnings,
        )
        protocols, _, _, _ = self.registry.snapshot()
        for protocol in protocols.values():
            inferred_role = self._certificate_role(
                protocol.dst_ip,
                protocol.dst_port,
                observation,
            )
            if inferred_role is None:
                continue

            packet_client_ip = (
                observation.dst_ip
                if inferred_role == "server"
                else observation.src_ip
            )
            if (
                protocol.src_ip
                and packet_client_ip
                and protocol.src_ip != packet_client_ip
            ):
                continue

            self.registry.link_certificate_to_crypto(
                cert_entry.bom_ref,
                protocol.bom_ref,
                role=observation.certificate_role or inferred_role,
            )

    @staticmethod
    def _certificate_role(
        server_ip: str,
        server_port: int,
        observation: DecodedObservation,
    ) -> str | None:
        # Ports disambiguate loopback captures where both peers have one IP.
        if (
            observation.src_port
            and server_port == observation.src_port
            and server_ip == observation.src_ip
        ):
            return "server"
        if (
            observation.dst_port
            and server_port == observation.dst_port
            and server_ip == observation.dst_ip
        ):
            return "client"
        if server_ip == observation.src_ip:
            return "server"
        if server_ip == observation.dst_ip:
            return "client"
        return None
