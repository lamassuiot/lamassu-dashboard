from __future__ import annotations

import base64
import re
from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import datetime, timezone
from itertools import zip_longest
from typing import Any, TypeAlias

from live_cbom.extractors.certificates import CertInfo, parse_der_certificates
from live_cbom.extractors.tls import (
    TLS_CIPHER_NAMES,
    TLS_NAMED_GROUPS,
    TLS_SIGNATURE_ALGORITHM_NAMES,
    TLS_VERSION_LABELS,
    TlsClientHelloInfo,
    TlsConnectionObservation,
    TlsHandshakeInfo,
    TlsKeyShareInfo,
    _normalize_u16_hex,
    is_grease_codepoint,
)

OBSERVATION_SCHEMA_VERSION = "tls-crypto-observation/1.1"
LEGACY_OBSERVATION_SCHEMA_VERSION = "1.0"
PHASE_STATUSES = {
    "observed",
    "observed_encrypted_record",
    "decrypted",
    "inferred",
    "encrypted_unavailable",
    "capture_incomplete",
    "unsupported_by_dissector",
    "malformed",
    "not_present",
    "not_applicable",
}
PHASE_PRESENCES = {
    "confirmed",
    "expected",
    "unknown",
    "absent",
    "not_applicable",
}
ObservationMapping: TypeAlias = dict[str, Any]


@dataclass(frozen=True)
class DecodedObservation:
    """Capture-library-independent information decoded from one observation."""

    src_ip: str = ""
    dst_ip: str = ""
    src_port: int = 0
    dst_port: int = 0
    stream_id: str | None = None
    tcp_syn: bool = False
    tls_connection: TlsConnectionObservation | None = None
    client_hello: TlsClientHelloInfo | None = None
    server_hello: TlsHandshakeInfo | None = None
    certificates: tuple[CertInfo, ...] = ()
    certificate_role: str | None = None
    certificate_requested: bool = False
    certificate_request_signature_algorithms: tuple[str, ...] = ()
    certificate_request_certificate_signature_algorithms: tuple[str, ...] = ()
    ip_version: int | None = None
    frame_numbers: tuple[int, ...] = ()
    server_handshake_signature_scheme: str | None = None
    client_handshake_signature_scheme: str | None = None
    negotiated_group: str | None = None
    # Adapter-owned phase entries that do not map to the CBOM domain model
    # (EncryptedExtensions, HRR, key-exchange metadata, visibility markers).
    phase_entries: Mapping[str, tuple[Mapping[str, Any], ...]] = field(
        default_factory=dict
    )


def get_value(
    data: Mapping[str, Any],
    *names: str,
    default: Any = None,
) -> Any:
    for name in names:
        if name in data:
            return data[name]
    return default


def as_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes", "on"}


def _validate_legacy_observation_mapping(payload: Mapping[str, Any]) -> None:
    """Enforce the dependency-free core of the legacy packet schema."""
    schema_version = str(
        get_value(payload, "schemaVersion", "schema_version", default="")
    )
    if schema_version != LEGACY_OBSERVATION_SCHEMA_VERSION:
        raise ValueError(
            "schemaVersion must be "
            f"{LEGACY_OBSERVATION_SCHEMA_VERSION!r}, got {schema_version!r}"
        )

    for canonical, alias in (("srcIp", "src_ip"), ("dstIp", "dst_ip")):
        value = get_value(payload, canonical, alias)
        if not isinstance(value, str):
            raise ValueError(f"{canonical} must be a string")

    for canonical, alias in (
        ("srcPort", "src_port"),
        ("dstPort", "dst_port"),
    ):
        value = get_value(payload, canonical, alias)
        if (
            not isinstance(value, int)
            or isinstance(value, bool)
            or not 0 <= value <= 65535
        ):
            raise ValueError(f"{canonical} must be an integer from 0 to 65535")

    stream_id = get_value(payload, "streamId", "stream_id")
    if stream_id is not None and (
        not isinstance(stream_id, str) or not stream_id
    ):
        raise ValueError("streamId must be a non-empty string")

    for canonical, alias in (
        ("tcpSyn", "tcp_syn"),
        ("certificateRequested", "certificate_requested"),
    ):
        value = get_value(payload, canonical, alias)
        if value is not None and not isinstance(value, bool):
            raise ValueError(f"{canonical} must be a boolean")


def _validate_endpoint(value: Any, name: str) -> None:
    if not isinstance(value, Mapping):
        raise ValueError(f"flow.endpoints.{name} must be an object")
    if not isinstance(value.get("ip"), str):
        raise ValueError(f"flow.endpoints.{name}.ip must be a string")
    port = value.get("port")
    if (
        not isinstance(port, int)
        or isinstance(port, bool)
        or not 0 <= port <= 65535
    ):
        raise ValueError(
            f"flow.endpoints.{name}.port must be an integer from 0 to 65535"
        )


def _validate_phased_observation_mapping(payload: Mapping[str, Any]) -> None:
    schema = payload.get("schema")
    if schema != OBSERVATION_SCHEMA_VERSION:
        raise ValueError(
            f"schema must be {OBSERVATION_SCHEMA_VERSION!r}, got {schema!r}"
        )

    flow = payload.get("flow")
    if not isinstance(flow, Mapping):
        raise ValueError("flow must be an object")
    if flow.get("transport") != "TCP":
        raise ValueError("flow.transport must be 'TCP'")
    ip_version = flow.get("ip_version")
    if ip_version is not None and ip_version not in {4, 6}:
        raise ValueError("flow.ip_version must be 4 or 6")
    endpoints = flow.get("endpoints")
    if not isinstance(endpoints, Mapping):
        raise ValueError("flow.endpoints must be an object")
    _validate_endpoint(endpoints.get("client"), "client")
    _validate_endpoint(endpoints.get("server"), "server")

    phases = payload.get("phases")
    if not isinstance(phases, Mapping):
        raise ValueError("phases must be an object")
    for phase_name, entries in phases.items():
        if not isinstance(entries, list):
            raise ValueError(f"phases.{phase_name} must be an array")
        for index, entry in enumerate(entries):
            path = f"phases.{phase_name}[{index}]"
            if not isinstance(entry, Mapping):
                raise ValueError(f"{path} must be an object")
            status = entry.get("status")
            if status not in PHASE_STATUSES:
                raise ValueError(f"{path}.status is invalid")
            presence = entry.get("presence")
            if presence is not None and presence not in PHASE_PRESENCES:
                raise ValueError(f"{path}.presence is invalid")
            if (
                status == "encrypted_unavailable"
                and presence not in {"expected", "unknown"}
            ):
                raise ValueError(
                    f"{path}.presence must be expected or unknown when "
                    "contents are encrypted"
                )
            if status == "not_present" and presence != "absent":
                raise ValueError(
                    f"{path}.presence must be absent when not present"
                )
            if (
                status == "not_applicable"
                and presence != "not_applicable"
            ):
                raise ValueError(
                    f"{path}.presence must be not_applicable"
                )
            direction = entry.get("direction")
            if direction is not None:
                if not isinstance(direction, Mapping):
                    raise ValueError(f"{path}.direction must be an object")
                source = direction.get("source")
                destination = direction.get("destination")
                if source not in {"client", "server"}:
                    raise ValueError(
                        f"{path}.direction.source must reference an endpoint"
                    )
                if destination not in {"client", "server"}:
                    raise ValueError(
                        f"{path}.direction.destination must reference an endpoint"
                    )
                if source == destination:
                    raise ValueError(
                        f"{path}.direction endpoints must be different"
                    )


def validate_observation_mapping(payload: Mapping[str, Any]) -> None:
    """Validate phased 1.1 observations and legacy packet observations."""
    if "schema" in payload:
        _validate_phased_observation_mapping(payload)
        return
    _validate_legacy_observation_mapping(payload)


def _as_list(value: Any) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, tuple):
        return list(value)
    return [value]


def _as_int(value: Any, default: int = 0) -> int:
    try:
        return int(str(value))
    except (TypeError, ValueError):
        return default


def _optional_text(value: Any) -> str | None:
    text = str(value).strip() if value is not None else ""
    return text or None


def _normalise_u16_code(value: Any) -> str:
    if isinstance(value, int) and not isinstance(value, bool):
        return f"0x{value:04x}" if 0 <= value <= 0xFFFF else hex(value)
    return _normalize_u16_hex(value)


def _normalise_version(value: Any) -> tuple[str, str]:
    text = str(value).strip()
    if not text:
        return "", ""
    label = re.sub(r"^tls\s*", "", text, flags=re.IGNORECASE)
    if label in TLS_VERSION_LABELS.values():
        version_hex = next(
            code
            for code, known_label in TLS_VERSION_LABELS.items()
            if known_label == label
        )
        return version_hex, label
    version_hex = _normalise_u16_code(value)
    if version_hex.startswith("0x") and is_grease_codepoint(version_hex):
        return "", ""
    return version_hex, TLS_VERSION_LABELS.get(version_hex, text)


def _normalise_group(value: Any) -> str | None:
    text = str(value).strip()
    if not text:
        return None
    code = _normalise_u16_code(value).lower()
    if code.startswith("0x"):
        if is_grease_codepoint(code):
            return None
        return TLS_NAMED_GROUPS.get(code, code)
    return text


def _normalise_signature(value: Any) -> str | None:
    text = str(value).strip()
    if not text:
        return None
    code = _normalise_u16_code(value).lower()
    if code.startswith("0x"):
        if is_grease_codepoint(code):
            return None
        return TLS_SIGNATURE_ALGORITHM_NAMES.get(code, code)
    return text


def _normalise_cipher(
    value: Any,
    explicit_name: Any = None,
) -> tuple[str, str] | None:
    if isinstance(value, Mapping):
        explicit_name = get_value(
            value,
            "name",
            "cipherName",
            default=explicit_name,
        )
        value = get_value(value, "id", "hex", "code", "value", default="")
    text = str(value).strip()
    if not text and explicit_name is None:
        return None
    if text.upper().startswith("TLS_"):
        return "", text
    code = _normalise_u16_code(value).lower() if text else ""
    if code and is_grease_codepoint(code):
        return None
    name = _optional_text(explicit_name)
    return code, name or TLS_CIPHER_NAMES.get(code, text)


def _parse_client_hello(
    payload: Mapping[str, Any],
    observation: Mapping[str, Any],
) -> TlsClientHelloInfo:
    explicit_hexes = _as_list(
        get_value(payload, "offeredCipherHexes", "offered_cipher_hexes")
    )
    explicit_names = _as_list(
        get_value(payload, "offeredCipherNames", "offered_cipher_names")
    )
    suites = _as_list(get_value(payload, "cipherSuites", "cipher_suites"))
    if not suites:
        suites = explicit_hexes

    cipher_hexes: list[str] = []
    cipher_names: list[str] = []
    seen: set[str] = set()
    for index, suite in enumerate(suites):
        explicit_name = (
            explicit_names[index] if index < len(explicit_names) else None
        )
        normalised = _normalise_cipher(suite, explicit_name)
        if normalised is None:
            continue
        code, name = normalised
        identity = code or name
        if identity in seen:
            continue
        seen.add(identity)
        cipher_hexes.append(code)
        cipher_names.append(name)

    versions: list[str] = []
    for value in _as_list(
        get_value(payload, "supportedVersions", "supported_versions")
    ):
        _, label = _normalise_version(value)
        if label and label not in versions:
            versions.append(label)

    groups: list[str] = []
    for value in _as_list(
        get_value(payload, "supportedGroups", "supported_groups")
    ):
        group = _normalise_group(value)
        if group and group not in groups:
            groups.append(group)

    signatures: list[str] = []
    for value in _as_list(
        get_value(payload, "signatureAlgorithms", "signature_algorithms")
    ):
        signature = _normalise_signature(value)
        if signature and signature not in signatures:
            signatures.append(signature)

    certificate_signatures: list[str] = []
    for value in _as_list(
        get_value(
            payload,
            "certificateSignatureSchemes",
            "certificate_signature_schemes",
            "certificateSignatureAlgorithms",
            "certificate_signature_algorithms",
        )
    ):
        signature = _normalise_signature(value)
        if signature and signature not in certificate_signatures:
            certificate_signatures.append(signature)

    key_shares: list[TlsKeyShareInfo] = []
    for value in _as_list(get_value(payload, "keyShares", "key_shares")):
        if isinstance(value, Mapping):
            group = _normalise_group(value.get("group"))
            length_value = get_value(
                value,
                "encodedLengthBytes",
                "encoded_length_bytes",
            )
            length = (
                _as_int(length_value)
                if length_value is not None
                else None
            )
        else:
            group = _normalise_group(value)
            length = None
        if group and group not in {item.group for item in key_shares}:
            key_shares.append(TlsKeyShareInfo(group, length))

    psk_modes = tuple(
        str(value)
        for value in _as_list(
            get_value(
                payload,
                "pskKeyExchangeModes",
                "psk_key_exchange_modes",
            )
        )
        if str(value) in {"psk_ke", "psk_dhe_ke"}
    )
    server_name = get_value(payload, "sni", "serverName", "server_name")
    if isinstance(server_name, Mapping):
        server_name = server_name.get("value")

    return TlsClientHelloInfo(
        src_ip=str(
            get_value(
                payload,
                "clientIp",
                "client_ip",
                default=get_value(
                    observation,
                    "srcIp",
                    "src_ip",
                    default="",
                ),
            )
        ),
        dst_ip=str(
            get_value(
                payload,
                "serverIp",
                "server_ip",
                default=get_value(
                    observation,
                    "dstIp",
                    "dst_ip",
                    default="",
                ),
            )
        ),
        dst_port=_as_int(
            get_value(
                payload,
                "serverPort",
                "server_port",
                default=get_value(
                    observation,
                    "dstPort",
                    "dst_port",
                    default=0,
                ),
            )
        ),
        sni=_optional_text(server_name),
        offered_cipher_hexes=cipher_hexes,
        offered_cipher_names=cipher_names,
        supported_versions=versions,
        supported_groups=tuple(groups),
        signature_algorithms=tuple(signatures),
        key_shares=tuple(key_shares),
        certificate_signature_algorithms=tuple(certificate_signatures),
        psk_key_exchange_modes=psk_modes,
        psk_identity_count=_as_int(
            get_value(
                payload,
                "pskIdentityCount",
                "psk_identity_count",
                default=0,
            )
        ),
    )


def _parse_server_hello(
    payload: Mapping[str, Any],
    observation: Mapping[str, Any],
) -> TlsHandshakeInfo:
    version_value = get_value(
        payload,
        "versionHex",
        "version_hex",
        "selectedVersion",
        "selected_version",
        "version",
        default="",
    )
    version_hex, version_label = _normalise_version(version_value)
    cipher_value = get_value(
        payload,
        "cipherSuite",
        "cipher_suite",
        "cipherHex",
        "cipher_hex",
        default="",
    )
    normalised_cipher = _normalise_cipher(
        cipher_value,
        get_value(payload, "cipherName", "cipher_name"),
    )
    cipher_hex, cipher_name = normalised_cipher or ("", "")
    key_share = get_value(payload, "keyShare", "key_share")
    group_value = (
        key_share.get("group")
        if isinstance(key_share, Mapping)
        else get_value(
            payload,
            "keyShareGroup",
            "key_share_group",
            "selectedGroup",
            "selected_group",
        )
    )
    group = _normalise_group(group_value)
    psk_index_value = get_value(
        payload,
        "pskIdentityIndex",
        "psk_identity_index",
    )

    return TlsHandshakeInfo(
        version_hex=version_hex,
        version_label=version_label,
        cipher_hex=cipher_hex,
        cipher_name=cipher_name,
        src_ip=str(
            get_value(
                payload,
                "clientIp",
                "client_ip",
                default=get_value(
                    observation,
                    "dstIp",
                    "dst_ip",
                    default="",
                ),
            )
        ),
        dst_ip=str(
            get_value(
                payload,
                "serverIp",
                "server_ip",
                default=get_value(
                    observation,
                    "srcIp",
                    "src_ip",
                    default="",
                ),
            )
        ),
        dst_port=_as_int(
            get_value(
                payload,
                "serverPort",
                "server_port",
                default=get_value(
                    observation,
                    "srcPort",
                    "src_port",
                    default=0,
                ),
            )
        ),
        sni=_optional_text(
            get_value(payload, "sni", "serverName", "server_name")
        ),
        key_share_group=group,
        psk_identity_index=(
            _as_int(psk_index_value)
            if psk_index_value is not None
            else None
        ),
        handshake_signature_scheme=_normalise_signature(
            get_value(
                payload,
                "handshakeSignatureScheme",
                "handshake_signature_scheme",
            )
        ),
        server_authentication_status=_optional_text(
            get_value(
                payload,
                "serverAuthenticationStatus",
                "server_authentication_status",
            )
        ),
    )


def _parse_tls_connection(
    payload: Mapping[str, Any],
) -> TlsConnectionObservation:
    return TlsConnectionObservation(
        handshake_type=str(
            get_value(payload, "handshakeType", "handshake_type", default="")
        ),
        src_ip=str(get_value(payload, "srcIp", "src_ip", default="")),
        dst_ip=str(get_value(payload, "dstIp", "dst_ip", default="")),
        dst_port=_as_int(
            get_value(payload, "dstPort", "dst_port", default=0)
        ),
        tls_version=str(
            get_value(payload, "tlsVersion", "tls_version", default="-")
        ),
        cipher_name=str(
            get_value(payload, "cipherName", "cipher_name", default="-")
        ),
        sni=_optional_text(
            get_value(payload, "sni", "serverName", "server_name")
        ),
    )


def _parse_datetime(value: Any, field_name: str) -> datetime:
    if isinstance(value, datetime):
        parsed = value
    else:
        text = str(value).strip()
        if not text:
            raise ValueError(f"certificate.{field_name} is required")
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed


def _parse_optional_datetime(value: Any, field_name: str) -> datetime | None:
    if value is None or value == "":
        return None
    return _parse_datetime(value, field_name)


def _decode_der(payload: Mapping[str, Any]) -> bytes | None:
    base64_value = get_value(payload, "derBase64", "der_base64")
    if base64_value:
        return base64.b64decode(str(base64_value), validate=True)
    hex_value = get_value(payload, "derHex", "der_hex")
    if hex_value:
        cleaned = re.sub(r"[\s:]", "", str(hex_value))
        return bytes.fromhex(cleaned.removeprefix("0x"))
    return None


def _parse_certificates(payloads: Any) -> tuple[CertInfo, ...]:
    certificates: list[CertInfo] = []
    for payload in _as_list(payloads):
        if not isinstance(payload, Mapping):
            raise ValueError("each certificate must be an object")
        der = _decode_der(payload)
        if der is not None:
            certificates.extend(parse_der_certificates([der]))
            continue
        public_key = get_value(payload, "publicKey", "public_key", default={})
        if not isinstance(public_key, Mapping):
            public_key = {}
        certificates.append(
            CertInfo(
                subject=str(get_value(payload, "subject", default="")),
                issuer=str(get_value(payload, "issuer", default="")),
                not_before=_parse_optional_datetime(
                    get_value(payload, "notBefore", "not_before"),
                    "notBefore",
                ),
                not_after=_parse_optional_datetime(
                    get_value(payload, "notAfter", "not_after"),
                    "notAfter",
                ),
                sig_algorithm=str(
                    get_value(
                        payload,
                        "signatureAlgorithm",
                        "certificateSignatureAlgorithm",
                        "certificate_signature_algorithm",
                        "sig_algorithm",
                        default="",
                    )
                ),
                public_key_type=str(
                    get_value(
                        payload,
                        "publicKeyType",
                        "public_key_type",
                        default=get_value(
                            public_key,
                            "algorithm",
                            default="",
                        ),
                    )
                ),
                public_key_size=_as_int(
                    get_value(
                        payload,
                        "publicKeySize",
                        "public_key_size",
                        default=get_value(
                            public_key,
                            "sizeBits",
                            "size_bits",
                            default=0,
                        ),
                    )
                ),
                fingerprint_sha256=str(
                    get_value(
                        payload,
                        "fingerprintSha256",
                        "sha256Fingerprint",
                        "sha256_fingerprint",
                        "fingerprint_sha256",
                        default="",
                    )
                ),
                pem=str(get_value(payload, "pem", default="")),
                public_key_group=_optional_text(
                    get_value(
                        public_key,
                        "namedGroup",
                        "named_group",
                    )
                ),
            )
        )
    return tuple(certificates)


def _decoded_legacy_observation_from_mapping(
    payload: Mapping[str, Any],
) -> DecodedObservation:
    """Convert one validated legacy packet mapping to the domain model."""

    client_payload = get_value(payload, "clientHello", "client_hello")
    server_payload = get_value(payload, "serverHello", "server_hello")
    connection_payload = get_value(
        payload,
        "tlsConnection",
        "tls_connection",
    )
    if client_payload is not None and not isinstance(client_payload, Mapping):
        raise ValueError("clientHello must be an object")
    if server_payload is not None and not isinstance(server_payload, Mapping):
        raise ValueError("serverHello must be an object")
    if (
        connection_payload is not None
        and not isinstance(connection_payload, Mapping)
    ):
        raise ValueError("tlsConnection must be an object")

    role = _optional_text(
        get_value(payload, "certificateRole", "certificate_role")
    )
    if role not in {None, "client", "server"}:
        raise ValueError("certificateRole must be 'client' or 'server'")

    return DecodedObservation(
        src_ip=str(get_value(payload, "srcIp", "src_ip", default="")),
        dst_ip=str(get_value(payload, "dstIp", "dst_ip", default="")),
        src_port=_as_int(
            get_value(payload, "srcPort", "src_port", default=0)
        ),
        dst_port=_as_int(
            get_value(payload, "dstPort", "dst_port", default=0)
        ),
        stream_id=_optional_text(
            get_value(
                payload,
                "streamId",
                "stream_id",
                "tcpStream",
                "tcp_stream",
            )
        ),
        tcp_syn=as_bool(
            get_value(payload, "tcpSyn", "tcp_syn", default=False)
        ),
        tls_connection=(
            _parse_tls_connection(connection_payload)
            if connection_payload is not None
            else None
        ),
        client_hello=(
            _parse_client_hello(client_payload, payload)
            if client_payload is not None
            else None
        ),
        server_hello=(
            _parse_server_hello(server_payload, payload)
            if server_payload is not None
            else None
        ),
        certificates=_parse_certificates(
            get_value(payload, "certificates", default=[])
        ),
        certificate_role=role,
        certificate_requested=as_bool(
            get_value(
                payload,
                "certificateRequested",
                "certificate_requested",
                default=False,
            )
        ),
    )


def _phase_is_available(phase: Mapping[str, Any]) -> bool:
    return phase.get("status") in {"observed", "decrypted", "inferred"}


def _phase_frame_numbers(phase: Mapping[str, Any]) -> tuple[int, ...]:
    return tuple(
        _as_int(value)
        for value in _as_list(phase.get("frame_numbers"))
        if _as_int(value) > 0
    )


def _phased_context(
    payload: Mapping[str, Any],
) -> tuple[Mapping[str, Any], Mapping[str, Any], str | None, int | None]:
    flow = payload["flow"]
    endpoints = flow["endpoints"]
    client = endpoints["client"]
    server = endpoints["server"]
    stream_id = _optional_text(flow.get("tcp_stream"))
    ip_version = flow.get("ip_version")
    return client, server, stream_id, ip_version


def _direction_values(
    phase: Mapping[str, Any],
    client: Mapping[str, Any],
    server: Mapping[str, Any],
) -> tuple[str, str, int, int]:
    direction = phase.get("direction")
    source_role = (
        direction.get("source")
        if isinstance(direction, Mapping)
        else "client"
    )
    source = client if source_role == "client" else server
    destination = server if source_role == "client" else client
    return (
        str(source["ip"]),
        str(destination["ip"]),
        _as_int(source["port"]),
        _as_int(destination["port"]),
    )


def _client_hello_from_phase(
    phase: Mapping[str, Any],
    client: Mapping[str, Any],
    server: Mapping[str, Any],
) -> TlsClientHelloInfo | None:
    if not _phase_is_available(phase):
        return None
    offered = phase.get("offered")
    if not isinstance(offered, Mapping):
        offered = {}
    server_name = phase.get("server_name")
    if isinstance(server_name, Mapping):
        server_name = server_name.get("value")
    normalized = {
        "clientIp": client["ip"],
        "serverIp": server["ip"],
        "serverPort": server["port"],
        "sni": server_name,
        "cipherSuites": offered.get("cipher_suites", []),
        "supportedVersions": offered.get("versions", []),
        "supportedGroups": offered.get("supported_groups", []),
        "keyShares": offered.get("key_shares", []),
        "signatureAlgorithms": offered.get("signature_schemes", []),
        "certificateSignatureSchemes": offered.get(
            "certificate_signature_schemes",
            [],
        ),
        "pskKeyExchangeModes": offered.get("psk_key_exchange_modes", []),
        "pskIdentityCount": offered.get("psk_identity_count", 0),
    }
    return _parse_client_hello(normalized, normalized)


def _first_available_phase(
    phases: Mapping[str, Any],
    name: str,
) -> Mapping[str, Any] | None:
    entries = phases.get(name, [])
    if not isinstance(entries, list):
        return None
    return next(
        (
            entry
            for entry in entries
            if isinstance(entry, Mapping) and _phase_is_available(entry)
        ),
        None,
    )


def _server_handshake_signature(
    phases: Mapping[str, Any],
) -> str | None:
    for phase_name in ("server_certificate_verify", "server_key_exchange"):
        phase = _first_available_phase(phases, phase_name)
        selected = phase.get("selected") if phase is not None else None
        if not isinstance(selected, Mapping):
            continue
        signature = _normalise_signature(selected.get("signature_scheme"))
        if signature:
            return signature
    return None


def _server_key_exchange_group(
    phases: Mapping[str, Any],
) -> str | None:
    phase = _first_available_phase(phases, "server_key_exchange")
    selected = phase.get("selected") if phase is not None else None
    if not isinstance(selected, Mapping):
        return None
    key_exchange = selected.get("key_exchange")
    if not isinstance(key_exchange, Mapping):
        return None
    return _normalise_group(key_exchange.get("group"))


def _server_hello_from_phase(
    phase: Mapping[str, Any],
    phases: Mapping[str, Any],
    client: Mapping[str, Any],
    server: Mapping[str, Any],
    server_name: str | None,
) -> TlsHandshakeInfo | None:
    if not _phase_is_available(phase):
        return None
    selected = phase.get("selected")
    if not isinstance(selected, Mapping):
        selected = {}
    server_certificate = next(
        (
            entry
            for entry in phases.get("server_certificate", [])
            if isinstance(entry, Mapping)
        ),
        None,
    )
    normalized = {
        "clientIp": client["ip"],
        "serverIp": server["ip"],
        "serverPort": server["port"],
        "version": selected.get("version", ""),
        "cipherSuite": selected.get("cipher_suite", ""),
        "keyShare": selected.get("key_share"),
        "pskIdentityIndex": selected.get("psk_identity_index"),
        "sni": server_name,
        "handshakeSignatureScheme": _server_handshake_signature(phases),
        "serverAuthenticationStatus": (
            server_certificate.get("status")
            if server_certificate is not None
            else None
        ),
    }
    handshake = _parse_server_hello(normalized, normalized)
    fallback_group = _server_key_exchange_group(phases)
    if handshake.key_share_group or not fallback_group:
        return handshake
    return TlsHandshakeInfo(
        version_hex=handshake.version_hex,
        version_label=handshake.version_label,
        cipher_hex=handshake.cipher_hex,
        cipher_name=handshake.cipher_name,
        src_ip=handshake.src_ip,
        dst_ip=handshake.dst_ip,
        dst_port=handshake.dst_port,
        sni=handshake.sni,
        key_share_group=fallback_group,
        psk_identity_index=handshake.psk_identity_index,
        handshake_signature_scheme=handshake.handshake_signature_scheme,
        server_authentication_status=(
            handshake.server_authentication_status
        ),
    )


def _certificate_chain_from_phase(
    phase: Mapping[str, Any],
) -> tuple[CertInfo, ...]:
    if not _phase_is_available(phase):
        return ()
    chain = phase.get("chain")
    if not isinstance(chain, list):
        return ()
    return _parse_certificates(chain)


def _decoded_phased_observations(
    payload: Mapping[str, Any],
) -> tuple[DecodedObservation, ...]:
    client, server, stream_id, ip_version = _phased_context(payload)
    phases = payload["phases"]
    summary = payload.get("summary")
    summary_name = summary.get("server_name") if isinstance(summary, Mapping) else None
    if isinstance(summary_name, Mapping):
        summary_name = summary_name.get("value")
    server_name = _optional_text(summary_name)
    decoded: list[DecodedObservation] = []

    def append_phase(
        phase: Mapping[str, Any],
        **values: Any,
    ) -> None:
        src_ip, dst_ip, src_port, dst_port = _direction_values(
            phase,
            client,
            server,
        )
        decoded.append(
            DecodedObservation(
                src_ip=src_ip,
                dst_ip=dst_ip,
                src_port=src_port,
                dst_port=dst_port,
                stream_id=stream_id,
                ip_version=ip_version,
                frame_numbers=_phase_frame_numbers(phase),
                **values,
            )
        )

    for phase in phases.get("client_hello", []):
        hello = _client_hello_from_phase(phase, client, server)
        if hello is not None:
            if hello.sni:
                server_name = hello.sni
            append_phase(
                phase,
                client_hello=hello,
                tls_connection=TlsConnectionObservation(
                    handshake_type="1",
                    src_ip=str(client["ip"]),
                    dst_ip=str(server["ip"]),
                    dst_port=_as_int(server["port"]),
                    tls_version=(
                        hello.supported_versions[0]
                        if hello.supported_versions
                        else "-"
                    ),
                    cipher_name="-",
                    sni=hello.sni,
                ),
            )

    for phase in phases.get("server_hello", []):
        hello = _server_hello_from_phase(
            phase,
            phases,
            client,
            server,
            server_name,
        )
        if hello is not None:
            append_phase(
                phase,
                server_hello=hello,
                tls_connection=TlsConnectionObservation(
                    handshake_type="2",
                    src_ip=str(server["ip"]),
                    dst_ip=str(client["ip"]),
                    dst_port=_as_int(client["port"]),
                    tls_version=hello.version_label or "-",
                    cipher_name=hello.cipher_name or "-",
                    sni=hello.sni,
                ),
            )

    for phase in phases.get("server_key_exchange", []):
        if not _phase_is_available(phase):
            continue
        selected = phase.get("selected")
        if not isinstance(selected, Mapping):
            continue
        key_exchange = selected.get("key_exchange")
        group = (
            _normalise_group(key_exchange.get("group"))
            if isinstance(key_exchange, Mapping)
            else None
        )
        signature = _normalise_signature(
            selected.get("signature_scheme")
        )
        if group or signature:
            append_phase(
                phase,
                negotiated_group=group,
                server_handshake_signature_scheme=signature,
            )

    for phase in phases.get("certificate_request", []):
        if _phase_is_available(phase) and phase.get("presence") == "confirmed":
            requested = phase.get("requested")
            if not isinstance(requested, Mapping):
                requested = {}
            append_phase(
                phase,
                certificate_requested=True,
                certificate_request_signature_algorithms=tuple(
                    signature
                    for value in _as_list(
                        requested.get("signature_schemes")
                    )
                    if (signature := _normalise_signature(value))
                ),
                certificate_request_certificate_signature_algorithms=tuple(
                    signature
                    for value in _as_list(
                        requested.get("certificate_signature_schemes")
                    )
                    if (signature := _normalise_signature(value))
                ),
            )

    for role, phase_name in (
        ("server", "server_certificate"),
        ("client", "client_certificate"),
    ):
        for phase in phases.get(phase_name, []):
            chain = _certificate_chain_from_phase(phase)
            if chain:
                append_phase(
                    phase,
                    certificates=chain,
                    certificate_role=role,
                )

    for role, phase_name in (
        ("server", "server_certificate_verify"),
        ("client", "client_certificate_verify"),
    ):
        for phase in phases.get(phase_name, []):
            if not _phase_is_available(phase):
                continue
            selected = phase.get("selected")
            if not isinstance(selected, Mapping):
                continue
            signature = _normalise_signature(
                selected.get("signature_scheme")
            )
            if not signature:
                continue
            append_phase(
                phase,
                **{
                    f"{role}_handshake_signature_scheme": signature,
                },
            )

    if decoded:
        return tuple(decoded)
    return (
        DecodedObservation(
            src_ip=str(client["ip"]),
            dst_ip=str(server["ip"]),
            src_port=_as_int(client["port"]),
            dst_port=_as_int(server["port"]),
            stream_id=stream_id,
            ip_version=ip_version,
        ),
    )


def decoded_observations_from_mapping(
    payload: Mapping[str, Any],
) -> tuple[DecodedObservation, ...]:
    """Convert a connection-level observation into analyzable phase events."""
    validate_observation_mapping(payload)
    if payload.get("schema") == OBSERVATION_SCHEMA_VERSION:
        return _decoded_phased_observations(payload)
    return (_decoded_legacy_observation_from_mapping(payload),)


def decoded_observation_from_mapping(
    payload: Mapping[str, Any],
) -> DecodedObservation:
    """Convert one mapping to a representative decoded observation.

    The analyzer uses :func:`decoded_observations_from_mapping` so every
    repeated phase is retained. This singular helper remains convenient for
    packet adapters and callers that know their mapping contains one event.
    """
    observations = decoded_observations_from_mapping(payload)
    if len(observations) == 1:
        return observations[0]

    first = observations[0]
    return DecodedObservation(
        src_ip=first.src_ip,
        dst_ip=first.dst_ip,
        src_port=first.src_port,
        dst_port=first.dst_port,
        stream_id=first.stream_id,
        ip_version=first.ip_version,
        client_hello=next(
            (item.client_hello for item in observations if item.client_hello),
            None,
        ),
        server_hello=next(
            (item.server_hello for item in observations if item.server_hello),
            None,
        ),
        certificates=next(
            (item.certificates for item in observations if item.certificates),
            (),
        ),
        certificate_role=next(
            (
                item.certificate_role
                for item in observations
                if item.certificate_role
            ),
            None,
        ),
        certificate_requested=any(
            item.certificate_requested for item in observations
        ),
        certificate_request_signature_algorithms=next(
            (
                item.certificate_request_signature_algorithms
                for item in observations
                if item.certificate_request_signature_algorithms
            ),
            (),
        ),
        certificate_request_certificate_signature_algorithms=next(
            (
                item.certificate_request_certificate_signature_algorithms
                for item in observations
                if item.certificate_request_certificate_signature_algorithms
            ),
            (),
        ),
        server_handshake_signature_scheme=next(
            (
                item.server_handshake_signature_scheme
                for item in observations
                if item.server_handshake_signature_scheme
            ),
            None,
        ),
        client_handshake_signature_scheme=next(
            (
                item.client_handshake_signature_scheme
                for item in observations
                if item.client_handshake_signature_scheme
            ),
            None,
        ),
        negotiated_group=next(
            (
                item.negotiated_group
                for item in observations
                if item.negotiated_group
            ),
            None,
        ),
    )


def _reverse_code(value: str, names: Mapping[str, str]) -> str:
    text = str(value).strip()
    if not text:
        return ""
    if text.lower().startswith("0x"):
        return _normalise_u16_code(text).lower()
    for code, name in names.items():
        if name == text:
            return code
    return text


def _datetime_text(value: datetime | None) -> str | None:
    if value is None:
        return None
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _display_tls_version(value: str) -> str:
    text = str(value).strip()
    if not text:
        return ""
    return text if text.upper().startswith("TLS ") else f"TLS {text}"


def _display_hash(value: str) -> str:
    match = re.fullmatch(r"SHA(\d+)", value.upper())
    return f"SHA-{match.group(1)}" if match else value


def _server_crypto_summary(server: TlsHandshakeInfo) -> ObservationMapping:
    cipher = server.cipher_name.upper()
    result: ObservationMapping = {}
    aes = re.search(r"AES_(128|256)_(GCM|CCM_8|CCM|CBC)", cipher)
    if aes:
        mode = aes.group(2).replace("_", "-")
        result["record_protection"] = {
            "algorithm": f"AES-{aes.group(1)}-{mode}",
            "key_size_bits": int(aes.group(1)),
        }
    elif "CHACHA20_POLY1305" in cipher:
        result["record_protection"] = {
            "algorithm": "ChaCha20-Poly1305",
            "key_size_bits": 256,
        }

    hash_match = re.search(r"_(SHA(?:256|384|512))$", cipher)
    hash_name = _display_hash(hash_match.group(1)) if hash_match else None
    if server.version_label == "1.3":
        result["key_derivation"] = {
            "algorithm": "HKDF",
            "hash": hash_name,
        }
        result["key_establishment"] = {
            "mode": "ephemeral_key_share",
            "group": server.key_share_group,
        }
    else:
        result["key_derivation"] = {
            "algorithm": "TLS 1.2 PRF",
            "hash": hash_name or "SHA-256",
        }
        family_match = re.match(r"TLS_([A-Z0-9]+(?:_[A-Z0-9]+)*)_WITH_", cipher)
        family = (
            family_match.group(1).split("_", 1)[0]
            if family_match
            else "unknown"
        )
        result["key_establishment"] = {
            "mode": family,
            "group": server.key_share_group,
        }
    authentication_status = server.server_authentication_status
    if not authentication_status and server.version_label == "1.3":
        authentication_status = (
            "encrypted_unavailable"
            if server.psk_identity_index is None
            else "not_applicable"
        )
    if authentication_status:
        result["server_authentication"] = {
            "mode": (
                "certificate_expected"
                if server.psk_identity_index is None
                else "psk"
            ),
            "status": authentication_status,
            "certificate_chain": None,
            "certificate_public_key_algorithm": None,
            "certificate_signature_algorithm": None,
            "handshake_signature_scheme": (
                server.handshake_signature_scheme
            ),
        }
    return result


def _flow_endpoints(
    observation: DecodedObservation,
) -> tuple[ObservationMapping, ObservationMapping]:
    if observation.client_hello is not None:
        client = observation.client_hello
        return (
            {"ip": client.src_ip, "port": observation.src_port},
            {"ip": client.dst_ip, "port": client.dst_port},
        )
    if observation.server_hello is not None:
        server = observation.server_hello
        client_port = (
            observation.dst_port
            if observation.src_ip == server.dst_ip
            else observation.src_port
        )
        return (
            {"ip": server.src_ip, "port": client_port},
            {"ip": server.dst_ip, "port": server.dst_port},
        )
    if observation.certificate_role == "server":
        return (
            {"ip": observation.dst_ip, "port": observation.dst_port},
            {"ip": observation.src_ip, "port": observation.src_port},
        )
    if observation.certificate_role == "client":
        return (
            {"ip": observation.src_ip, "port": observation.src_port},
            {"ip": observation.dst_ip, "port": observation.dst_port},
        )
    connection = observation.tls_connection
    if connection is not None and connection.handshake_type == "2":
        return (
            {"ip": connection.dst_ip, "port": observation.dst_port},
            {"ip": connection.src_ip, "port": observation.src_port},
        )
    return (
        {"ip": observation.src_ip, "port": observation.src_port},
        {"ip": observation.dst_ip, "port": observation.dst_port},
    )


def _phase_base(
    observation: DecodedObservation,
    source: str,
    destination: str,
) -> ObservationMapping:
    result: ObservationMapping = {
        "direction": {
            "source": source,
            "destination": destination,
        },
        "status": "observed",
        "presence": "confirmed",
    }
    if observation.frame_numbers:
        result["frame_numbers"] = list(observation.frame_numbers)
    return result


def _certificate_mapping(
    certificate: CertInfo,
    position: int,
) -> ObservationMapping:
    public_key: ObservationMapping = {
        "algorithm": certificate.public_key_type,
        "size_bits": certificate.public_key_size,
    }
    if certificate.public_key_group:
        public_key["named_group"] = certificate.public_key_group
    result: ObservationMapping = {
        "position": position,
        "sha256_fingerprint": certificate.fingerprint_sha256,
        "subject": certificate.subject,
        "issuer": certificate.issuer,
        "public_key": public_key,
        "certificate_signature_algorithm": certificate.sig_algorithm,
    }
    not_before = _datetime_text(certificate.not_before)
    not_after = _datetime_text(certificate.not_after)
    if not_before is not None:
        result["not_before"] = not_before
    if not_after is not None:
        result["not_after"] = not_after
    if certificate.pem:
        result["pem"] = certificate.pem
    return result


def _tls13_unavailable_phases(
    server: TlsHandshakeInfo,
) -> ObservationMapping:
    certificate_expected = server.psk_identity_index is None
    certificate_presence = "expected" if certificate_expected else "not_applicable"
    certificate_status = (
        "encrypted_unavailable" if certificate_expected else "not_applicable"
    )
    certificate_reason = (
        "The ServerHello did not select a PSK, so certificate authentication "
        "is expected, but the TLS 1.3 Certificate message is encrypted"
        if certificate_expected
        else "The ServerHello selected a PSK and certificate authentication "
        "is not applicable"
    )
    return {
        "encrypted_extensions": [
            {
                "direction": {
                    "source": "server",
                    "destination": "client",
                },
                "status": "encrypted_unavailable",
                "presence": "expected",
                "reason": (
                    "TLS 1.3 encrypts EncryptedExtensions and no traffic "
                    "secrets were available"
                ),
            }
        ],
        "server_certificate": [
            {
                "direction": {
                    "source": "server",
                    "destination": "client",
                },
                "status": certificate_status,
                "presence": certificate_presence,
                "reason": certificate_reason,
                "chain": None,
            }
        ],
        "server_key_exchange": [
            {
                "status": "not_applicable",
                "presence": "not_applicable",
                "reason": "ServerKeyExchange does not exist in TLS 1.3",
            }
        ],
        "server_certificate_verify": [
            {
                "direction": {
                    "source": "server",
                    "destination": "client",
                },
                "status": certificate_status,
                "presence": certificate_presence,
                "reason": (
                    "CertificateVerify is encrypted in TLS 1.3 and no "
                    "traffic secrets were available"
                    if certificate_expected
                    else certificate_reason
                ),
                "selected": {"signature_scheme": None},
            }
        ],
        "certificate_request": [
            {
                "direction": {
                    "source": "server",
                    "destination": "client",
                },
                "status": "encrypted_unavailable",
                "presence": "unknown",
                "reason": (
                    "The encrypted handshake prevents determining whether "
                    "the server requested client authentication"
                ),
                "requested": None,
            }
        ],
        "client_certificate": [
            {
                "direction": {
                    "source": "client",
                    "destination": "server",
                },
                "status": "encrypted_unavailable",
                "presence": "unknown",
                "reason": (
                    "The encrypted handshake prevents determining whether "
                    "the client sent a certificate"
                ),
                "chain": None,
            }
        ],
        "client_key_exchange": [
            {
                "status": "not_applicable",
                "presence": "not_applicable",
                "reason": "ClientKeyExchange does not exist in TLS 1.3",
            }
        ],
        "client_certificate_verify": [
            {
                "direction": {
                    "source": "client",
                    "destination": "server",
                },
                "status": "encrypted_unavailable",
                "presence": "unknown",
                "reason": (
                    "The encrypted handshake prevents determining whether "
                    "the client used CertificateVerify"
                ),
                "selected": {"signature_scheme": None},
            }
        ],
    }


def decoded_observation_to_mapping(
    observation: DecodedObservation,
) -> ObservationMapping:
    """Encode one decoded event using the phased TLS crypto schema."""
    client_endpoint, server_endpoint = _flow_endpoints(observation)
    ip_version = observation.ip_version
    if ip_version is None:
        sample_ip = str(client_endpoint["ip"] or server_endpoint["ip"])
        ip_version = 6 if ":" in sample_ip else 4
    flow: ObservationMapping = {
        "transport": "TCP",
        "ip_version": ip_version,
        "endpoints": {
            "client": client_endpoint,
            "server": server_endpoint,
        },
    }
    if observation.stream_id:
        flow["tcp_stream"] = (
            int(observation.stream_id)
            if observation.stream_id.isdigit()
            else observation.stream_id
        )

    phases: ObservationMapping = {
        name: [dict(entry) for entry in entries]
        for name, entries in observation.phase_entries.items()
    }
    summary: ObservationMapping = {}

    client = observation.client_hello
    if client is not None:
        suites: list[str] = []
        for code, name in zip_longest(
            client.offered_cipher_hexes,
            client.offered_cipher_names,
            fillvalue="",
        ):
            identity = name or TLS_CIPHER_NAMES.get(code, code)
            if not identity or is_grease_codepoint(code):
                continue
            suites.append(identity)
        entry = _phase_base(observation, "client", "server")
        entry.update(
            {
                "sequence": 1,
                "server_name": {
                    "value": client.sni,
                    "status": "observed" if client.sni else "not_present",
                    "source": "sni",
                    "ech_protected": False,
                },
                "offered": {
                    "versions": [
                        _display_tls_version(value)
                        for value in client.supported_versions
                    ],
                    "cipher_suites": suites,
                    "supported_groups": list(client.supported_groups),
                    "key_shares": [
                        {
                            "group": key_share.group,
                            **(
                                {
                                    "encoded_length_bytes": (
                                        key_share.encoded_length_bytes
                                    )
                                }
                                if key_share.encoded_length_bytes is not None
                                else {}
                            ),
                        }
                        for key_share in client.key_shares
                    ],
                    "signature_schemes": list(
                        client.signature_algorithms
                    ),
                    "certificate_signature_schemes": list(
                        client.certificate_signature_algorithms
                    ),
                    "psk_key_exchange_modes": list(
                        client.psk_key_exchange_modes
                    ),
                    "psk_identity_count": client.psk_identity_count,
                },
            }
        )
        phases.setdefault("client_hello", []).append(entry)
        if client.sni:
            summary["server_name"] = {
                "value": client.sni,
                "status": "observed",
            }

    server = observation.server_hello
    if server is not None:
        selected: ObservationMapping = {
            "version": _display_tls_version(server.version_label),
            "cipher_suite": server.cipher_name,
            "key_share": (
                {"group": server.key_share_group}
                if server.key_share_group
                else None
            ),
            "psk_identity_index": server.psk_identity_index,
        }
        entry = _phase_base(observation, "server", "client")
        entry.update({"sequence": 2, "selected": selected})
        phases.setdefault("server_hello", []).append(entry)
        summary.update(
            {
                "version": _display_tls_version(server.version_label),
                "cipher_suite": server.cipher_name,
            }
        )
        summary.update(_server_crypto_summary(server))
        if server.version_label == "1.3":
            summary["client_authentication"] = {
                "mode": "unknown",
                "status": "encrypted_unavailable",
                "certificate_chain": None,
                "certificate_public_key_algorithm": None,
                "certificate_signature_algorithm": None,
                "handshake_signature_scheme": None,
            }
        if server.sni and "server_name" not in summary:
            summary["server_name"] = {
                "value": server.sni,
                "status": "inferred",
            }
        if server.version_label == "1.3":
            for phase_name, entries in _tls13_unavailable_phases(
                server
            ).items():
                phases.setdefault(phase_name, entries)

    if observation.certificate_requested:
        if "certificate_request" not in phases:
            entry = _phase_base(observation, "server", "client")
            entry["requested"] = {
                "signature_schemes": list(
                    observation.certificate_request_signature_algorithms
                ),
                "certificate_signature_schemes": list(
                    observation.certificate_request_certificate_signature_algorithms
                ),
                "certificate_authorities": [],
            }
            phases["certificate_request"] = [entry]

    if observation.certificates and observation.certificate_role:
        role = observation.certificate_role
        entry = _phase_base(
            observation,
            role,
            "client" if role == "server" else "server",
        )
        if server is not None and server.version_label == "1.3":
            entry["status"] = "decrypted"
        entry["chain"] = [
            _certificate_mapping(certificate, position)
            for position, certificate in enumerate(observation.certificates)
        ]
        phase_name = f"{role}_certificate"
        existing = phases.get(phase_name, [])
        if any(
            phase.get("status") == "encrypted_unavailable"
            for phase in existing
        ):
            phases[phase_name] = [entry]
        else:
            phases.setdefault(phase_name, []).append(entry)
        leaf = observation.certificates[0]
        summary[f"{role}_authentication"] = {
            "mode": "certificate",
            "status": entry["status"],
            "certificate_chain": entry["chain"],
            "certificate_public_key_algorithm": leaf.public_key_type,
            "certificate_signature_algorithm": leaf.sig_algorithm,
            "handshake_signature_scheme": (
                observation.server_handshake_signature_scheme
                if role == "server"
                else observation.client_handshake_signature_scheme
            ),
        }

    for role, signature in (
        ("server", observation.server_handshake_signature_scheme),
        ("client", observation.client_handshake_signature_scheme),
    ):
        if not signature:
            continue
        entry = _phase_base(
            observation,
            role,
            "client" if role == "server" else "server",
        )
        entry["selected"] = {"signature_scheme": signature}
        phase_name = f"{role}_certificate_verify"
        if phase_name not in phases:
            phases[phase_name] = [entry]

    payload: ObservationMapping = {
        "schema": OBSERVATION_SCHEMA_VERSION,
        "flow": flow,
        "phases": phases,
    }
    if summary:
        payload["summary"] = summary
    return payload
