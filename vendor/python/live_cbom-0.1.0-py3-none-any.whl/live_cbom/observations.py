from __future__ import annotations

import base64
import re
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import datetime, timezone
from itertools import zip_longest
from typing import Any, TypeAlias

from live_cbom.extractors.certificates import CertInfo, parse_der_certificates
from live_cbom.extractors.tls import (
    TLS_CIPHER_NAMES,
    TLS_NAMED_GROUPS,
    TLS_SIGNATURE_ALGORITHM_NAMES,
    TLS_VERSION_LABELS,
    TlsClientHelloInfo,
    TlsConnectionObservation,
    TlsHandshakeInfo,
    _normalize_u16_hex,
    is_grease_codepoint,
)

OBSERVATION_SCHEMA_VERSION = "1.0"
ObservationMapping: TypeAlias = dict[str, Any]


@dataclass(frozen=True)
class DecodedObservation:
    """Capture-library-independent information decoded from one observation."""

    src_ip: str = ""
    dst_ip: str = ""
    src_port: int = 0
    dst_port: int = 0
    stream_id: str | None = None
    tcp_syn: bool = False
    tls_connection: TlsConnectionObservation | None = None
    client_hello: TlsClientHelloInfo | None = None
    server_hello: TlsHandshakeInfo | None = None
    certificates: tuple[CertInfo, ...] = ()
    certificate_role: str | None = None
    certificate_requested: bool = False


def get_value(
    data: Mapping[str, Any],
    *names: str,
    default: Any = None,
) -> Any:
    for name in names:
        if name in data:
            return data[name]
    return default


def as_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes", "on"}


def validate_observation_mapping(payload: Mapping[str, Any]) -> None:
    """Enforce the dependency-free core of the Observation v1 schema."""
    schema_version = str(
        get_value(payload, "schemaVersion", "schema_version", default="")
    )
    if schema_version != OBSERVATION_SCHEMA_VERSION:
        raise ValueError(
            "schemaVersion must be "
            f"{OBSERVATION_SCHEMA_VERSION!r}, got {schema_version!r}"
        )

    for canonical, alias in (("srcIp", "src_ip"), ("dstIp", "dst_ip")):
        value = get_value(payload, canonical, alias)
        if not isinstance(value, str):
            raise ValueError(f"{canonical} must be a string")

    for canonical, alias in (
        ("srcPort", "src_port"),
        ("dstPort", "dst_port"),
    ):
        value = get_value(payload, canonical, alias)
        if (
            not isinstance(value, int)
            or isinstance(value, bool)
            or not 0 <= value <= 65535
        ):
            raise ValueError(f"{canonical} must be an integer from 0 to 65535")

    stream_id = get_value(payload, "streamId", "stream_id")
    if stream_id is not None and (
        not isinstance(stream_id, str) or not stream_id
    ):
        raise ValueError("streamId must be a non-empty string")

    for canonical, alias in (
        ("tcpSyn", "tcp_syn"),
        ("certificateRequested", "certificate_requested"),
    ):
        value = get_value(payload, canonical, alias)
        if value is not None and not isinstance(value, bool):
            raise ValueError(f"{canonical} must be a boolean")


def _as_list(value: Any) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, tuple):
        return list(value)
    return [value]


def _as_int(value: Any, default: int = 0) -> int:
    try:
        return int(str(value))
    except (TypeError, ValueError):
        return default


def _optional_text(value: Any) -> str | None:
    text = str(value).strip() if value is not None else ""
    return text or None


def _normalise_u16_code(value: Any) -> str:
    if isinstance(value, int) and not isinstance(value, bool):
        return f"0x{value:04x}" if 0 <= value <= 0xFFFF else hex(value)
    return _normalize_u16_hex(value)


def _normalise_version(value: Any) -> tuple[str, str]:
    text = str(value).strip()
    if not text:
        return "", ""
    label = re.sub(r"^tls\s*", "", text, flags=re.IGNORECASE)
    if label in TLS_VERSION_LABELS.values():
        version_hex = next(
            code
            for code, known_label in TLS_VERSION_LABELS.items()
            if known_label == label
        )
        return version_hex, label
    version_hex = _normalise_u16_code(value)
    if version_hex.startswith("0x") and is_grease_codepoint(version_hex):
        return "", ""
    return version_hex, TLS_VERSION_LABELS.get(version_hex, text)


def _normalise_group(value: Any) -> str | None:
    text = str(value).strip()
    if not text:
        return None
    code = _normalise_u16_code(value).lower()
    if code.startswith("0x"):
        if is_grease_codepoint(code):
            return None
        return TLS_NAMED_GROUPS.get(code, code)
    return text


def _normalise_signature(value: Any) -> str | None:
    text = str(value).strip()
    if not text:
        return None
    code = _normalise_u16_code(value).lower()
    if code.startswith("0x"):
        if is_grease_codepoint(code):
            return None
        return TLS_SIGNATURE_ALGORITHM_NAMES.get(code, code)
    return text


def _normalise_cipher(
    value: Any,
    explicit_name: Any = None,
) -> tuple[str, str] | None:
    if isinstance(value, Mapping):
        explicit_name = get_value(
            value,
            "name",
            "cipherName",
            default=explicit_name,
        )
        value = get_value(value, "id", "hex", "code", "value", default="")
    text = str(value).strip()
    if not text and explicit_name is None:
        return None
    if text.upper().startswith("TLS_"):
        return "", text
    code = _normalise_u16_code(value).lower() if text else ""
    if code and is_grease_codepoint(code):
        return None
    name = _optional_text(explicit_name)
    return code, name or TLS_CIPHER_NAMES.get(code, text)


def _parse_client_hello(
    payload: Mapping[str, Any],
    observation: Mapping[str, Any],
) -> TlsClientHelloInfo:
    explicit_hexes = _as_list(
        get_value(payload, "offeredCipherHexes", "offered_cipher_hexes")
    )
    explicit_names = _as_list(
        get_value(payload, "offeredCipherNames", "offered_cipher_names")
    )
    suites = _as_list(get_value(payload, "cipherSuites", "cipher_suites"))
    if not suites:
        suites = explicit_hexes

    cipher_hexes: list[str] = []
    cipher_names: list[str] = []
    seen: set[str] = set()
    for index, suite in enumerate(suites):
        explicit_name = (
            explicit_names[index] if index < len(explicit_names) else None
        )
        normalised = _normalise_cipher(suite, explicit_name)
        if normalised is None:
            continue
        code, name = normalised
        identity = code or name
        if identity in seen:
            continue
        seen.add(identity)
        cipher_hexes.append(code)
        cipher_names.append(name)

    versions: list[str] = []
    for value in _as_list(
        get_value(payload, "supportedVersions", "supported_versions")
    ):
        _, label = _normalise_version(value)
        if label and label not in versions:
            versions.append(label)

    groups: list[str] = []
    for value in _as_list(
        get_value(payload, "supportedGroups", "supported_groups")
    ):
        group = _normalise_group(value)
        if group and group not in groups:
            groups.append(group)

    signatures: list[str] = []
    for value in _as_list(
        get_value(payload, "signatureAlgorithms", "signature_algorithms")
    ):
        signature = _normalise_signature(value)
        if signature and signature not in signatures:
            signatures.append(signature)

    return TlsClientHelloInfo(
        src_ip=str(
            get_value(
                payload,
                "clientIp",
                "client_ip",
                default=get_value(
                    observation,
                    "srcIp",
                    "src_ip",
                    default="",
                ),
            )
        ),
        dst_ip=str(
            get_value(
                payload,
                "serverIp",
                "server_ip",
                default=get_value(
                    observation,
                    "dstIp",
                    "dst_ip",
                    default="",
                ),
            )
        ),
        dst_port=_as_int(
            get_value(
                payload,
                "serverPort",
                "server_port",
                default=get_value(
                    observation,
                    "dstPort",
                    "dst_port",
                    default=0,
                ),
            )
        ),
        sni=_optional_text(
            get_value(payload, "sni", "serverName", "server_name")
        ),
        offered_cipher_hexes=cipher_hexes,
        offered_cipher_names=cipher_names,
        supported_versions=versions,
        supported_groups=tuple(groups),
        signature_algorithms=tuple(signatures),
    )


def _parse_server_hello(
    payload: Mapping[str, Any],
    observation: Mapping[str, Any],
) -> TlsHandshakeInfo:
    version_value = get_value(
        payload,
        "versionHex",
        "version_hex",
        "selectedVersion",
        "selected_version",
        "version",
        default="",
    )
    version_hex, version_label = _normalise_version(version_value)
    cipher_value = get_value(
        payload,
        "cipherSuite",
        "cipher_suite",
        "cipherHex",
        "cipher_hex",
        default="",
    )
    normalised_cipher = _normalise_cipher(
        cipher_value,
        get_value(payload, "cipherName", "cipher_name"),
    )
    cipher_hex, cipher_name = normalised_cipher or ("", "")
    group = _normalise_group(
        get_value(
            payload,
            "keyShareGroup",
            "key_share_group",
            "selectedGroup",
            "selected_group",
        )
    )

    return TlsHandshakeInfo(
        version_hex=version_hex,
        version_label=version_label,
        cipher_hex=cipher_hex,
        cipher_name=cipher_name,
        src_ip=str(
            get_value(
                payload,
                "clientIp",
                "client_ip",
                default=get_value(
                    observation,
                    "dstIp",
                    "dst_ip",
                    default="",
                ),
            )
        ),
        dst_ip=str(
            get_value(
                payload,
                "serverIp",
                "server_ip",
                default=get_value(
                    observation,
                    "srcIp",
                    "src_ip",
                    default="",
                ),
            )
        ),
        dst_port=_as_int(
            get_value(
                payload,
                "serverPort",
                "server_port",
                default=get_value(
                    observation,
                    "srcPort",
                    "src_port",
                    default=0,
                ),
            )
        ),
        sni=_optional_text(
            get_value(payload, "sni", "serverName", "server_name")
        ),
        key_share_group=group,
    )


def _parse_tls_connection(
    payload: Mapping[str, Any],
) -> TlsConnectionObservation:
    return TlsConnectionObservation(
        handshake_type=str(
            get_value(payload, "handshakeType", "handshake_type", default="")
        ),
        src_ip=str(get_value(payload, "srcIp", "src_ip", default="")),
        dst_ip=str(get_value(payload, "dstIp", "dst_ip", default="")),
        dst_port=_as_int(
            get_value(payload, "dstPort", "dst_port", default=0)
        ),
        tls_version=str(
            get_value(payload, "tlsVersion", "tls_version", default="-")
        ),
        cipher_name=str(
            get_value(payload, "cipherName", "cipher_name", default="-")
        ),
        sni=_optional_text(
            get_value(payload, "sni", "serverName", "server_name")
        ),
    )


def _parse_datetime(value: Any, field_name: str) -> datetime:
    if isinstance(value, datetime):
        parsed = value
    else:
        text = str(value).strip()
        if not text:
            raise ValueError(f"certificate.{field_name} is required")
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed


def _decode_der(payload: Mapping[str, Any]) -> bytes | None:
    base64_value = get_value(payload, "derBase64", "der_base64")
    if base64_value:
        return base64.b64decode(str(base64_value), validate=True)
    hex_value = get_value(payload, "derHex", "der_hex")
    if hex_value:
        cleaned = re.sub(r"[\s:]", "", str(hex_value))
        return bytes.fromhex(cleaned.removeprefix("0x"))
    return None


def _parse_certificates(payloads: Any) -> tuple[CertInfo, ...]:
    certificates: list[CertInfo] = []
    for payload in _as_list(payloads):
        if not isinstance(payload, Mapping):
            raise ValueError("each certificate must be an object")
        der = _decode_der(payload)
        if der is not None:
            certificates.extend(parse_der_certificates([der]))
            continue
        certificates.append(
            CertInfo(
                subject=str(get_value(payload, "subject", default="")),
                issuer=str(get_value(payload, "issuer", default="")),
                not_before=_parse_datetime(
                    get_value(payload, "notBefore", "not_before"),
                    "notBefore",
                ),
                not_after=_parse_datetime(
                    get_value(payload, "notAfter", "not_after"),
                    "notAfter",
                ),
                sig_algorithm=str(
                    get_value(
                        payload,
                        "signatureAlgorithm",
                        "sig_algorithm",
                        default="",
                    )
                ),
                public_key_type=str(
                    get_value(
                        payload,
                        "publicKeyType",
                        "public_key_type",
                        default="",
                    )
                ),
                public_key_size=_as_int(
                    get_value(
                        payload,
                        "publicKeySize",
                        "public_key_size",
                        default=0,
                    )
                ),
                fingerprint_sha256=str(
                    get_value(
                        payload,
                        "fingerprintSha256",
                        "fingerprint_sha256",
                        default="",
                    )
                ),
                pem=str(get_value(payload, "pem", default="")),
            )
        )
    return tuple(certificates)


def decoded_observation_from_mapping(
    payload: Mapping[str, Any],
) -> DecodedObservation:
    """Validate and convert one Observation v1 mapping to the domain model."""
    validate_observation_mapping(payload)

    client_payload = get_value(payload, "clientHello", "client_hello")
    server_payload = get_value(payload, "serverHello", "server_hello")
    connection_payload = get_value(
        payload,
        "tlsConnection",
        "tls_connection",
    )
    if client_payload is not None and not isinstance(client_payload, Mapping):
        raise ValueError("clientHello must be an object")
    if server_payload is not None and not isinstance(server_payload, Mapping):
        raise ValueError("serverHello must be an object")
    if (
        connection_payload is not None
        and not isinstance(connection_payload, Mapping)
    ):
        raise ValueError("tlsConnection must be an object")

    role = _optional_text(
        get_value(payload, "certificateRole", "certificate_role")
    )
    if role not in {None, "client", "server"}:
        raise ValueError("certificateRole must be 'client' or 'server'")

    return DecodedObservation(
        src_ip=str(get_value(payload, "srcIp", "src_ip", default="")),
        dst_ip=str(get_value(payload, "dstIp", "dst_ip", default="")),
        src_port=_as_int(
            get_value(payload, "srcPort", "src_port", default=0)
        ),
        dst_port=_as_int(
            get_value(payload, "dstPort", "dst_port", default=0)
        ),
        stream_id=_optional_text(
            get_value(
                payload,
                "streamId",
                "stream_id",
                "tcpStream",
                "tcp_stream",
            )
        ),
        tcp_syn=as_bool(
            get_value(payload, "tcpSyn", "tcp_syn", default=False)
        ),
        tls_connection=(
            _parse_tls_connection(connection_payload)
            if connection_payload is not None
            else None
        ),
        client_hello=(
            _parse_client_hello(client_payload, payload)
            if client_payload is not None
            else None
        ),
        server_hello=(
            _parse_server_hello(server_payload, payload)
            if server_payload is not None
            else None
        ),
        certificates=_parse_certificates(
            get_value(payload, "certificates", default=[])
        ),
        certificate_role=role,
        certificate_requested=as_bool(
            get_value(
                payload,
                "certificateRequested",
                "certificate_requested",
                default=False,
            )
        ),
    )


def _reverse_code(value: str, names: Mapping[str, str]) -> str:
    text = str(value).strip()
    if not text:
        return ""
    if text.lower().startswith("0x"):
        return _normalise_u16_code(text).lower()
    for code, name in names.items():
        if name == text:
            return code
    return text


def _datetime_text(value: datetime) -> str:
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def decoded_observation_to_mapping(
    observation: DecodedObservation,
) -> ObservationMapping:
    """Encode a domain observation as the canonical JSON-compatible mapping."""
    payload: ObservationMapping = {
        "schemaVersion": OBSERVATION_SCHEMA_VERSION,
        "srcIp": observation.src_ip,
        "dstIp": observation.dst_ip,
        "srcPort": observation.src_port,
        "dstPort": observation.dst_port,
        "tcpSyn": observation.tcp_syn,
        "certificateRequested": observation.certificate_requested,
    }
    if observation.stream_id:
        payload["streamId"] = observation.stream_id

    connection = observation.tls_connection
    if connection is not None:
        payload["tlsConnection"] = {
            "handshakeType": connection.handshake_type,
            "srcIp": connection.src_ip,
            "dstIp": connection.dst_ip,
            "dstPort": connection.dst_port,
            "tlsVersion": connection.tls_version,
            "cipherName": connection.cipher_name,
            "sni": connection.sni,
        }

    client = observation.client_hello
    if client is not None:
        suites = []
        for code, name in zip_longest(
            client.offered_cipher_hexes,
            client.offered_cipher_names,
            fillvalue="",
        ):
            identity = _reverse_code(code or name, TLS_CIPHER_NAMES)
            if not identity:
                continue
            suite: ObservationMapping = {"id": identity}
            if name:
                suite["name"] = name
            suites.append(suite)
        payload["clientHello"] = {
            "clientIp": client.src_ip,
            "serverIp": client.dst_ip,
            "serverPort": client.dst_port,
            "sni": client.sni,
            "cipherSuites": suites,
            "supportedVersions": [
                _reverse_code(value, TLS_VERSION_LABELS)
                for value in client.supported_versions
            ],
            "supportedGroups": [
                _reverse_code(value, TLS_NAMED_GROUPS)
                for value in client.supported_groups
            ],
            "signatureAlgorithms": [
                _reverse_code(value, TLS_SIGNATURE_ALGORITHM_NAMES)
                for value in client.signature_algorithms
            ],
        }

    server = observation.server_hello
    if server is not None:
        payload["serverHello"] = {
            "clientIp": server.src_ip,
            "serverIp": server.dst_ip,
            "serverPort": server.dst_port,
            "version": server.version_hex
            or _reverse_code(server.version_label, TLS_VERSION_LABELS),
            "cipherSuite": server.cipher_hex
            or _reverse_code(server.cipher_name, TLS_CIPHER_NAMES),
            "cipherName": server.cipher_name,
            "sni": server.sni,
            "keyShareGroup": (
                _reverse_code(server.key_share_group, TLS_NAMED_GROUPS)
                if server.key_share_group
                else None
            ),
        }

    if observation.certificates:
        payload["certificates"] = [
            {
                "subject": certificate.subject,
                "issuer": certificate.issuer,
                "notBefore": _datetime_text(certificate.not_before),
                "notAfter": _datetime_text(certificate.not_after),
                "signatureAlgorithm": certificate.sig_algorithm,
                "publicKeyType": certificate.public_key_type,
                "publicKeySize": certificate.public_key_size,
                "fingerprintSha256": certificate.fingerprint_sha256,
                "pem": certificate.pem,
            }
            for certificate in observation.certificates
        ]
    if observation.certificate_role:
        payload["certificateRole"] = observation.certificate_role
    return payload
