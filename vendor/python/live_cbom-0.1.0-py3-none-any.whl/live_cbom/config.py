from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Config:
    interface: str = "any"
    output_path: str = "cbom.json"
    flush_interval_sec: int = 5
    bom_component_name: str = "live-capture"
    bom_component_version: str = "1.0.0"
    # When True, protocol entries are grouped by (TLS version + cipher suite)
    # — one CBOM component per unique cipher.  When False (default), each
    # unique connection (SNI / dst IP:port) produces its own component.
    compact: bool = False
    # Path to an NSS-format TLS key-log file (e.g. one written by `ecapture tls
    # -m keylog`). When set, tshark decrypts TLS 1.3 records with it, so
    # extractors/certificates.py can see the encrypted Certificate message.
    keylog_path: str | None = None
    # Browser adapters do not own a key-log path: Wiregasm applies the keylog
    # before it emits observations. This flag preserves the same visibility
    # semantics without inventing a filesystem path inside Pyodide.
    keylog_available: bool = False
    # Optional JSON/NDJSON/YAML stream containing the normalized observations
    # emitted by the active capture adapter.
    observations_output_path: str | None = None

    @property
    def has_keylog(self) -> bool:
        return bool(self.keylog_path or self.keylog_available)

    @classmethod
    def from_env(cls) -> "Config":
        raw_interface = os.getenv("CBOM_INTERFACE", "any").strip()
        interface = "any" if raw_interface.lower() in {"all", "any"} else raw_interface
        return cls(
            interface=interface,
            output_path=os.getenv("CBOM_OUTPUT_PATH", "cbom.json"),
            flush_interval_sec=int(os.getenv("CBOM_FLUSH_INTERVAL", "5")),
            bom_component_name=os.getenv("CBOM_COMPONENT_NAME", "live-capture"),
            bom_component_version=os.getenv("CBOM_COMPONENT_VERSION", "1.0.0"),
            compact=os.getenv("CBOM_COMPACT", "").strip().lower() in {"1", "true", "yes"},
            keylog_path=os.getenv("CBOM_KEYLOG_FILE", "").strip() or None,
            observations_output_path=(
                os.getenv("CBOM_OBSERVATIONS_OUTPUT", "").strip() or None
            ),
        )
