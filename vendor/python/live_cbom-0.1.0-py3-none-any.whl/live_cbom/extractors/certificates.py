from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from collections.abc import Iterable
from typing import Any

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization


@dataclass(frozen=True)
class CertInfo:
    subject: str
    issuer: str
    not_before: datetime
    not_after: datetime
    sig_algorithm: str
    public_key_type: str
    public_key_size: int
    fingerprint_sha256: str
    pem: str


def _read_u24(data: bytes, offset: int) -> int:
    return (data[offset] << 16) | (data[offset + 1] << 8) | data[offset + 2]


def _decode_hex_blob(text: str) -> bytes:
    cleaned = text.replace(":", "").replace(" ", "").strip()
    if cleaned.startswith("0x"):
        cleaned = cleaned[2:]
    return bytes.fromhex(cleaned)


def _parse_der_object_length(data: bytes, offset: int) -> int | None:
    if offset + 2 > len(data):
        return None
    if data[offset] != 0x30:
        return None

    first_len_byte = data[offset + 1]
    if first_len_byte < 0x80:
        total_len = 2 + first_len_byte
        return total_len if offset + total_len <= len(data) else None

    length_octets = first_len_byte & 0x7F
    if length_octets == 0 or length_octets > 4:
        return None
    if offset + 2 + length_octets > len(data):
        return None

    content_len = int.from_bytes(data[offset + 2 : offset + 2 + length_octets], byteorder="big")
    total_len = 2 + length_octets + content_len
    return total_len if offset + total_len <= len(data) else None


def _is_cert_der(data: bytes) -> bool:
    try:
        x509.load_der_x509_certificate(data)
        return True
    except ValueError:
        return False


def _split_tls12_certificate_list(blob: bytes) -> list[bytes]:
    if len(blob) < 3:
        return []
    cert_list_len = _read_u24(blob, 0)
    if cert_list_len <= 0 or cert_list_len > len(blob) - 3:
        return []

    certs: list[bytes] = []
    offset = 3
    end = 3 + cert_list_len
    while offset + 3 <= end:
        cert_len = _read_u24(blob, offset)
        offset += 3
        if cert_len <= 0 or offset + cert_len > end:
            return []
        cert_der = blob[offset : offset + cert_len]
        offset += cert_len
        certs.append(cert_der)

    if offset != end:
        return []
    return certs


def _split_tls13_certificate_list(blob: bytes) -> list[bytes]:
    if len(blob) < 4:
        return []
    context_len = blob[0]
    if 1 + context_len + 3 > len(blob):
        return []

    offset = 1 + context_len
    cert_list_len = _read_u24(blob, offset)
    offset += 3
    end = offset + cert_list_len
    if cert_list_len <= 0 or end > len(blob):
        return []

    certs: list[bytes] = []
    while offset + 3 <= end:
        cert_len = _read_u24(blob, offset)
        offset += 3
        if cert_len <= 0 or offset + cert_len > end:
            return []
        cert_der = blob[offset : offset + cert_len]
        offset += cert_len

        if offset + 2 > end:
            return []
        ext_len = int.from_bytes(blob[offset : offset + 2], byteorder="big")
        offset += 2
        if offset + ext_len > end:
            return []
        offset += ext_len
        certs.append(cert_der)

    if offset != end:
        return []
    return certs


def _scan_for_der_certs(blob: bytes) -> list[bytes]:
    certs: list[bytes] = []
    seen: set[bytes] = set()
    idx = 0
    while idx < len(blob):
        if blob[idx] != 0x30:
            idx += 1
            continue

        obj_len = _parse_der_object_length(blob, idx)
        if obj_len is None:
            idx += 1
            continue

        candidate = blob[idx : idx + obj_len]
        if candidate not in seen and _is_cert_der(candidate):
            certs.append(candidate)
            seen.add(candidate)
            idx += obj_len
            continue
        idx += 1
    return certs


def _extract_certs_from_blob(blob: bytes) -> list[bytes]:
    if not blob:
        return []

    if _is_cert_der(blob):
        return [blob]

    for parser in (_split_tls12_certificate_list, _split_tls13_certificate_list):
        parsed = parser(blob)
        if parsed and all(_is_cert_der(item) for item in parsed):
            return parsed

    return _scan_for_der_certs(blob)


def _iter_field_occurrences(field: Any) -> list[Any]:
    """Expand a pyshark field to every repeated occurrence within one layer.

    A field name that appears more than once in a layer (e.g. one
    ``tls.handshake.certificate`` per certificate in a multi-cert chain) comes
    back from pyshark as a ``LayerFieldsContainer`` — a ``str`` subclass whose
    plain value/attribute access only reflects the *first* occurrence
    (``main_field``); the rest are reachable only via ``.all_fields``. Without
    unpacking that, chains beyond the first certificate are silently dropped.
    """
    all_fields = getattr(field, "all_fields", None)
    if all_fields:
        return list(all_fields)
    if isinstance(field, list):
        return field
    return [field]


def _extract_der_blobs(pkt: Any) -> list[bytes]:
    tls = getattr(pkt, "tls", None) or getattr(pkt, "ssl", None)
    if tls is None:
        return []

    candidates: list[bytes] = []

    # Try common pyshark attribute spellings first.
    for attr in ("handshake_certificate", "handshake_certificates", "handshake_certificate_raw"):
        field = getattr(tls, attr, None)
        if field is None:
            continue
        for item in _iter_field_occurrences(field):
            raw = getattr(item, "binary_value", None)
            if raw:
                candidates.append(bytes(raw))
                continue
            try:
                candidates.append(_decode_hex_blob(str(item)))
            except ValueError:
                continue

    fields = getattr(tls, "_all_fields", {})
    for key, value in fields.items():
        key_lower = key.lower().replace(".", "_")
        if "handshake_certificate" not in key_lower and "handshake_certificates" not in key_lower:
            continue
        for item in _iter_field_occurrences(value):
            raw = getattr(item, "binary_value", None)
            if raw:
                candidates.append(bytes(raw))
                continue
            try:
                candidates.append(_decode_hex_blob(str(item)))
            except ValueError:
                continue
    expanded: list[bytes] = []
    for blob in candidates:
        expanded.extend(_extract_certs_from_blob(blob))

    # Keep stable order while deduplicating.
    seen: set[bytes] = set()
    ordered_unique: list[bytes] = []
    for der in expanded:
        if der in seen:
            continue
        seen.add(der)
        ordered_unique.append(der)
    return ordered_unique


def _normalize_key_type(public_key: Any) -> str:
    name = public_key.__class__.__name__
    if name.startswith("RSA"):
        return "RSA"
    if name.startswith("DSA"):
        return "DSA"
    if name.startswith("EllipticCurve"):
        return "EC"
    if name.startswith("Ed25519"):
        return "Ed25519"
    if name.startswith("Ed448"):
        return "Ed448"
    return name.replace("PublicKey", "")


def parse_der_certificates(blobs: Iterable[bytes]) -> list[CertInfo]:
    """Parse DER certificates supplied by any capture adapter.

    Each input may be a single DER certificate, a TLS 1.2/1.3 certificate
    list, or a larger blob containing DER objects. This is the portable
    certificate boundary used by both PyShark and browser/Wiregasm adapters.
    """
    certs: list[CertInfo] = []
    seen: set[str] = set()
    for blob in blobs:
        for der in _extract_certs_from_blob(bytes(blob)):
            try:
                cert = x509.load_der_x509_certificate(der)
            except ValueError:
                continue

            fp = cert.fingerprint(hashes.SHA256()).hex()
            if fp in seen:
                continue
            seen.add(fp)

            public_key = cert.public_key()
            key_type = _normalize_key_type(public_key)
            key_size = getattr(public_key, "key_size", 0)
            sig_oid_name = cert.signature_algorithm_oid._name or cert.signature_algorithm_oid.dotted_string

            certs.append(
                CertInfo(
                    subject=cert.subject.rfc4514_string(),
                    issuer=cert.issuer.rfc4514_string(),
                    not_before=cert.not_valid_before_utc,
                    not_after=cert.not_valid_after_utc,
                    sig_algorithm=sig_oid_name,
                    public_key_type=key_type,
                    public_key_size=int(key_size) if key_size else 0,
                    fingerprint_sha256=fp,
                    pem=cert.public_bytes(serialization.Encoding.PEM).decode("ascii"),
                )
            )
    return certs


def parse_certificate(pkt: Any) -> list[CertInfo]:
    tls = getattr(pkt, "tls", None) or getattr(pkt, "ssl", None)
    if tls is None:
        return []

    # NOTE: we deliberately do not gate on `handshake_type` containing "11"
    # (Certificate). When TLS 1.3 bundles multiple handshake sub-messages
    # into one record, pyshark's plain attribute access can hide repeated
    # handshake types. Certificate candidates are validated as X.509 DER.
    return parse_der_certificates(_extract_der_blobs(pkt))
