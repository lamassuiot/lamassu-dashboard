from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any


TLS_VERSION_LABELS = {
    "0x0304": "1.3",
    "0x0303": "1.2",
    "0x0302": "1.1",
    "0x0301": "1.0",
}

# IANA TLS Supported Groups Registry (RFC 8422, RFC 7919, RFC 8446)
TLS_NAMED_GROUPS: dict[str, str] = {
    "0x0001": "sect163k1",
    "0x0002": "sect163r1",
    "0x0003": "sect163r2",
    "0x0004": "sect193r1",
    "0x0005": "sect193r2",
    "0x0006": "sect233k1",
    "0x0007": "sect233r1",
    "0x0008": "sect239k1",
    "0x000f": "secp160k1",
    "0x0010": "secp160r1",
    "0x0011": "secp160r2",
    "0x0012": "secp192k1",
    "0x0013": "secp192r1",
    "0x0014": "secp224k1",
    "0x0015": "secp224r1",
    "0x0017": "secp256r1",
    "0x0018": "secp384r1",
    "0x0019": "secp521r1",
    "0x001d": "x25519",
    "0x001e": "x448",
    "0x0100": "ffdhe2048",
    "0x0101": "ffdhe3072",
    "0x0102": "ffdhe4096",
    "0x0103": "ffdhe6144",
    "0x0104": "ffdhe8192",
    # Post-quantum hybrid ECDHE + ML-KEM (IANA-registered, draft-ietf-tls-ecdhe-mlkem)
    "0x11eb": "SecP256r1MLKEM768",
    "0x11ec": "X25519MLKEM768",
    "0x11ed": "SecP384r1MLKEM1024",
    "0x11ee": "curveSM2MLKEM768",
    # Pure ML-KEM (draft-ietf-tls-mlkem; codepoints still draft)
    "0x0200": "mlkem512",
    "0x0201": "mlkem768",
    "0x0202": "mlkem1024",
    # Obsolete pre-standard Kyber (still seen in older captures)
    "0x6399": "X25519Kyber768Draft00",
    "0x639a": "SecP256r1Kyber768Draft00",
}

# IANA TLS SignatureScheme registry (RFC 8446). The list focuses on schemes
# commonly observed in ClientHello signature_algorithms extensions.
TLS_SIGNATURE_ALGORITHM_NAMES: dict[str, str] = {
    "0x0201": "rsa_pkcs1_sha1",
    "0x0202": "dsa_sha1",
    "0x0203": "ecdsa_sha1",
    "0x0301": "rsa_pkcs1_sha224",
    "0x0302": "dsa_sha224",
    "0x0303": "ecdsa_secp224r1_sha224",
    "0x0401": "rsa_pkcs1_sha256",
    "0x0402": "dsa_sha256",
    "0x0403": "ecdsa_secp256r1_sha256",
    "0x0501": "rsa_pkcs1_sha384",
    "0x0502": "dsa_sha384",
    "0x0503": "ecdsa_secp384r1_sha384",
    "0x0601": "rsa_pkcs1_sha512",
    "0x0602": "dsa_sha512",
    "0x0603": "ecdsa_secp521r1_sha512",
    "0x0804": "rsa_pss_rsae_sha256",
    "0x0805": "rsa_pss_rsae_sha384",
    "0x0806": "rsa_pss_rsae_sha512",
    "0x0807": "ed25519",
    "0x0808": "ed448",
    "0x0809": "rsa_pss_pss_sha256",
    "0x080a": "rsa_pss_pss_sha384",
    "0x080b": "rsa_pss_pss_sha512",
    "0x081a": "ecdsa_brainpoolP256r1tls13_sha256",
    "0x081b": "ecdsa_brainpoolP384r1tls13_sha384",
    "0x081c": "ecdsa_brainpoolP512r1tls13_sha512",
}

# RFC 8446 / IANA TLS cipher suite registry — covers TLS 1.2 and 1.3 suites
# commonly seen in the wild. Keyed by normalised lowercase hex (e.g. "0x1301").
TLS_CIPHER_NAMES: dict[str, str] = {
    # TLS 1.3 (RFC 8446)
    "0x1301": "TLS_AES_128_GCM_SHA256",
    "0x1302": "TLS_AES_256_GCM_SHA384",
    "0x1303": "TLS_CHACHA20_POLY1305_SHA256",
    "0x1304": "TLS_AES_128_CCM_SHA256",
    "0x1305": "TLS_AES_128_CCM_8_SHA256",
    # TLS 1.2 ECDHE-RSA
    "0xc02b": "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256",
    "0xc02c": "TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384",
    "0xc02f": "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256",
    "0xc030": "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384",
    "0xcca8": "TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256",
    "0xcca9": "TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256",
    "0xc013": "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA",
    "0xc014": "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA",
    "0xc009": "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA",
    "0xc00a": "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA",
    # TLS 1.2 DHE
    "0x009e": "TLS_DHE_RSA_WITH_AES_128_GCM_SHA256",
    "0x009f": "TLS_DHE_RSA_WITH_AES_256_GCM_SHA384",
    "0xccaa": "TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256",
    # TLS 1.2 RSA (legacy)
    "0x002f": "TLS_RSA_WITH_AES_128_CBC_SHA",
    "0x0035": "TLS_RSA_WITH_AES_256_CBC_SHA",
    "0x003c": "TLS_RSA_WITH_AES_128_CBC_SHA256",
    "0x003d": "TLS_RSA_WITH_AES_256_CBC_SHA256",
    "0x009c": "TLS_RSA_WITH_AES_128_GCM_SHA256",
    "0x009d": "TLS_RSA_WITH_AES_256_GCM_SHA384",
    # Weak / legacy (flagged by weak_crypto)
    "0x000a": "TLS_RSA_WITH_3DES_EDE_CBC_SHA",
    "0x0004": "TLS_RSA_WITH_RC4_128_MD5",
    "0x0005": "TLS_RSA_WITH_RC4_128_SHA",
}


@dataclass(frozen=True)
class TlsHandshakeInfo:
    version_hex: str
    version_label: str
    cipher_hex: str
    cipher_name: str
    src_ip: str
    dst_ip: str
    dst_port: int
    sni: str | None
    # Key exchange group selected by the server (from key_share extension).
    key_share_group: str | None = None


@dataclass(frozen=True)
class TlsConnectionObservation:
    handshake_type: str
    src_ip: str
    dst_ip: str
    dst_port: int
    tls_version: str
    cipher_name: str
    sni: str | None


@dataclass(frozen=True)
class TlsClientHelloInfo:
    src_ip: str
    dst_ip: str
    dst_port: int
    sni: str | None
    offered_cipher_hexes: list[str]
    offered_cipher_names: list[str]
    supported_versions: list[str]
    # Named groups advertised by the client (supported_groups extension).
    supported_groups: tuple[str, ...] = ()
    # Signature schemes advertised by the client (signature_algorithms ext).
    signature_algorithms: tuple[str, ...] = ()


def is_grease_codepoint(value: Any) -> bool:
    """Return True for RFC 8701 GREASE values (0x0a0a, 0x1a1a, ..., 0xfafa).

    GREASE codepoints are deliberate decoys advertised in cipher_suites,
    supported_groups, signature_algorithms, key_share and supported_versions.
    They must never be recorded as real algorithms.
    """
    if isinstance(value, int):
        cp = value
    else:
        normalized = _normalize_u16_hex(value)
        if not normalized.startswith("0x"):
            return False
        try:
            cp = int(normalized, 16)
        except ValueError:
            return False
    # Both bytes identical and low nibble of each is 0xA.
    return (cp >> 8) == (cp & 0xFF) and (cp & 0x0F0F) == 0x0A0A


def _resolve_cipher_name(hex_or_name: str, pyshark_showname: str = "") -> str:
    """Return a human-readable cipher suite name.

    Prefers pyshark's showname attribute when present, then falls back to the
    built-in lookup table, and finally returns the raw value unchanged.
    """
    if pyshark_showname and not pyshark_showname.lower().startswith("0x") and not pyshark_showname.isdigit():
        return pyshark_showname.strip()
    normalised = _normalize_u16_hex(hex_or_name).lower()
    return TLS_CIPHER_NAMES.get(normalised, hex_or_name)


def _extract_cipher_name_from_text(text: str) -> str | None:
    cleaned = str(text).strip()
    if not cleaned:
        return None

    # Common tshark render: "TLS_AES_256_GCM_SHA384 (0x1302)"
    match = re.search(r"(TLS_[A-Z0-9_]+)\s*\(0x[0-9a-fA-F]{1,4}\)", cleaned)
    if match:
        return match.group(1)

    # Alternate render: "Cipher Suite: TLS_AES_256_GCM_SHA384 (0x1302)"
    match = re.search(r"Cipher Suite:\s*(TLS_[A-Z0-9_]+)", cleaned)
    if match:
        return match.group(1)

    # If string is already a TLS suite symbol, accept it as-is.
    if re.fullmatch(r"TLS_[A-Z0-9_]+", cleaned):
        return cleaned
    return None


def _resolve_cipher_name_from_field(field: Any, hex_value: str) -> str:
    for attr in ("showname", "show", "display", "pretty_value"):
        value = getattr(field, attr, None)
        if value is None:
            continue
        extracted = _extract_cipher_name_from_text(str(value))
        if extracted:
            return extracted
    return _resolve_cipher_name(hex_value)


def _normalize_hex(value: Any) -> str:
    text = str(value).strip().lower()
    if text.startswith("0x"):
        return text
    if text.isdigit():
        return hex(int(text))
    return text


def _normalize_u16_hex(value: Any) -> str:
    text = str(value).strip().lower()
    try:
        if text.startswith("0x"):
            num = int(text, 16)
        elif re.fullmatch(r"[0-9a-f]{1,4}", text):
            num = int(text, 16)
        elif text.isdigit():
            num = int(text, 10)
        else:
            return _normalize_hex(value)
        if 0 <= num <= 0xFFFF:
            return f"0x{num:04x}"
        return hex(num)
    except ValueError:
        return _normalize_hex(value)


def _get_ip_layer(pkt: Any) -> Any:
    ip = getattr(pkt, "ip", None)
    if ip is not None:
        return ip
    return getattr(pkt, "ipv6", None)


def _parse_handshake_types(tls: Any) -> set[str]:
    """Return every handshake type present on this layer (e.g. {"2","8","13",
    "11","15","20"} for a TLS 1.3 record bundling ServerHello through Finished).

    A repeated field name (like `tls.handshake.type` when several handshake
    sub-messages are coalesced into one record) comes back from pyshark as a
    container whose plain value only reflects the *first* occurrence -- the
    rest are reachable only via `.all_fields`. Detecting "1"/"2" happened to
    work before despite that (they're always first in their flight), but
    anything else (e.g. "13" for CertificateRequest) would be silently missed
    without expanding every occurrence here.
    """
    field = getattr(tls, "handshake_type", None)
    if field is None:
        field = getattr(tls, "handshake_type_raw", None)
    if field is None:
        return set()

    occurrences = getattr(field, "all_fields", None)
    if occurrences:
        # `.show` is pyshark's decimal-formatted display value (e.g. "13").
        # `.raw_value` is the field's raw hex WITHOUT a "0x" prefix (e.g. "0d"
        # for 13, "14" for 20) -- appropriate for extracting certificate bytes
        # elsewhere, but ambiguous here: a bare "14" would otherwise be
        # misread as decimal 14 instead of hex 0x14 (=20).
        texts = []
        for item in occurrences:
            show = getattr(item, "show", None)
            texts.append(str(show) if show is not None else str(getattr(item, "raw_value", None) or item))
    else:
        texts = [str(field)]

    parsed: set[str] = set()
    for text in texts:
        for token in re.split(r"[,\s]+", text.strip()):
            token = token.strip().lower()
            if not token:
                continue
            if token.startswith("0x"):
                try:
                    parsed.add(str(int(token, 16)))
                    continue
                except ValueError:
                    pass
            if token.isdigit():
                parsed.add(str(int(token)))
                continue
            match = re.match(r"^(\d+)", token)
            if match:
                parsed.add(str(int(match.group(1))))
    return parsed


def parse_certificate_request(pkt: Any) -> bool:
    """Return True if this packet carries a TLS CertificateRequest (handshake
    type 13) -- the server asking the client to authenticate via mTLS."""
    tls = getattr(pkt, "tls", None) or getattr(pkt, "ssl", None)
    if tls is None:
        return False
    return "13" in _parse_handshake_types(tls)


def _collect_tls_values(
    tls: Any,
    attr_names: tuple[str, ...],
    key_fragments: tuple[str, ...],
    *,
    exclude_key_fragments: tuple[str, ...] = (),
) -> list[Any]:
    values: list[Any] = []
    for attr in attr_names:
        raw = getattr(tls, attr, None)
        if raw is None:
            continue
        if isinstance(raw, list):
            values.extend(raw)
        else:
            values.append(raw)

    fields = getattr(tls, "_all_fields", {})
    for key, raw in fields.items():
        key_lower = key.lower().replace(".", "_")
        if not any(fragment in key_lower for fragment in key_fragments):
            continue
        if any(fragment in key_lower for fragment in exclude_key_fragments):
            continue
        if isinstance(raw, list):
            values.extend(raw)
        else:
            values.append(raw)
    return values


def _extract_u16_hex_candidates(value: Any) -> list[str]:
    # Prefer explicit hex identifiers (e.g. 0x1301). Decimal parsing is only
    # used when the entire value is a numeric list to avoid false positives
    # from strings like "TLS_AES_128_GCM_SHA256".
    text = str(value).strip()
    found: list[str] = []

    hex_tokens = re.findall(r"0x[0-9a-fA-F]{1,4}", text)
    for token in hex_tokens:
        try:
            found.append(_normalize_u16_hex(token))
        except ValueError:
            continue
    if found:
        return [cp for cp in found if not is_grease_codepoint(cp)]

    decimal_list = re.fullmatch(r"\d{1,5}(?:\s*,\s*\d{1,5})*", text)
    if not decimal_list:
        return []

    for token in re.split(r"\s*,\s*", text):
        try:
            number = int(token, 10)
        except ValueError:
            continue
        if 0 <= number <= 0xFFFF:
            found.append(_normalize_u16_hex(number))
    return [cp for cp in found if not is_grease_codepoint(cp)]


def _candidate_field_strings(value: Any) -> list[str]:
    texts: list[str] = []
    raw_value = getattr(value, "raw_value", None)
    if raw_value is not None:
        texts.append(str(raw_value))
    show = getattr(value, "show", None)
    if show is not None:
        texts.append(str(show))
    showname = getattr(value, "showname", None)
    if showname is not None:
        texts.append(str(showname))
    texts.append(str(value))
    return texts


def _extract_tls_version(tls: Any) -> tuple[str, str]:
    for attr in (
        "handshake_extensions_supported_version",
        "handshake_extension_supported_version",
        "handshake_extensions_supported_versions",
    ):
        value = getattr(tls, attr, None)
        if value:
            raw = _normalize_u16_hex(value)
            return raw, TLS_VERSION_LABELS.get(raw, raw)

    version_hex = _normalize_u16_hex(getattr(tls, "handshake_version", ""))
    if version_hex == "":
        version_hex = _normalize_u16_hex(getattr(tls, "record_version", ""))
    return version_hex, TLS_VERSION_LABELS.get(version_hex, version_hex)


def _extract_supported_versions(tls: Any) -> list[str]:
    labels: list[str] = []
    seen: set[str] = set()

    def _add(hex_value: str) -> None:
        # Only TLS record versions (0x03xx); GREASE never starts with 0x03 but
        # guard explicitly so a 0x?A?A decoy can never become a "version".
        if not hex_value.startswith("0x03") or is_grease_codepoint(hex_value):
            return
        label = TLS_VERSION_LABELS.get(hex_value, hex_value)
        if label not in seen:
            seen.add(label)
            labels.append(label)

    # Preferred path: pyshark repeated-field container with one entry per
    # offered version (the ClientHello supported_versions list).
    for attr in (
        "handshake_extensions_supported_version",
        "handshake_extension_supported_version",
        "handshake_extensions_supported_versions",
    ):
        container = getattr(tls, attr, None)
        all_fields = getattr(container, "all_fields", None)
        if not all_fields:
            continue
        for field in all_fields:
            raw_value = getattr(field, "raw_value", None)
            if raw_value is None:
                continue
            _add(_normalize_u16_hex(str(raw_value).lower()))
    if labels:
        return labels

    raw_values = _collect_tls_values(
        tls,
        attr_names=(
            "handshake_extensions_supported_version",
            "handshake_extension_supported_version",
            "handshake_extensions_supported_versions",
        ),
        key_fragments=("supported_version",),
        exclude_key_fragments=("len", "length"),
    )
    for value in raw_values:
        for hex_value in _extract_u16_hex_candidates(value):
            _add(hex_value)
    if labels:
        return labels

    # Fall back to legacy version when supported_versions extension is missing.
    _, fallback = _extract_tls_version(tls)
    if fallback and not is_grease_codepoint(fallback):
        return [fallback]
    return []


def _extract_supported_groups(tls: Any) -> list[str]:
    """Extract TLS named groups from supported_groups or key_share extensions.

    Covers both ClientHello (supported_groups lists all groups) and
    ServerHello (key_share carries the single selected group).
    """
    # Preferred path: pyshark repeated-field containers with one entry per
    # supported_group / key_share Group.
    groups: list[str] = []
    seen: set[str] = set()
    for attr in (
        "handshake_extensions_supported_group",
        "handshake_extension_supported_group",
        "handshake_extensions_supported_groups",
        "handshake_extension_supported_groups",
        "handshake_extensions_elliptic_curves",
        "handshake_extensions_key_share_group",
        "handshake_extension_key_share_group",
    ):
        container = getattr(tls, attr, None)
        all_fields = getattr(container, "all_fields", None)
        if not all_fields:
            continue
        for field in all_fields:
            raw_value = getattr(field, "raw_value", None)
            if raw_value is None:
                continue
            hex_val = _normalize_u16_hex(str(raw_value).lower()).lower()
            if not hex_val.startswith("0x") or is_grease_codepoint(hex_val):
                continue
            name = TLS_NAMED_GROUPS.get(hex_val, hex_val)
            if name in seen:
                continue
            seen.add(name)
            groups.append(name)
    if groups:
        return groups

    raw_values = _collect_tls_values(
        tls,
        attr_names=(
            "handshake_extensions_key_share_group",
            "handshake_extension_key_share_group",
            "handshake_extensions_supported_groups",
            "handshake_extension_supported_groups",
            "handshake_extensions_elliptic_curves",
        ),
        key_fragments=("key_share_group", "supported_group", "elliptic_curve"),
        exclude_key_fragments=("len", "length"),
    )
    groups: list[str] = []
    seen: set[str] = set()
    for value in raw_values:
        for hex_val in _extract_u16_hex_candidates(value):
            name = TLS_NAMED_GROUPS.get(hex_val, hex_val)
            if name not in seen:
                seen.add(name)
                groups.append(name)
    return groups


def _extract_signature_algorithms(tls: Any) -> list[str]:
    """Extract TLS signature schemes from the signature_algorithms extension."""
    # Preferred path: pyshark field container with one entry per SignatureScheme.
    for attr in (
        "handshake_sig_hash_alg",
        "handshake_sig_hash_algs",
        "handshake_signature_algorithm",
        "handshake_signature_algorithms",
    ):
        container = getattr(tls, attr, None)
        all_fields = getattr(container, "all_fields", None)
        if not all_fields:
            continue
        schemes: list[str] = []
        seen: set[str] = set()
        for field in all_fields:
            raw_value = getattr(field, "raw_value", None)
            if raw_value is None:
                continue
            hex_value = _normalize_u16_hex(str(raw_value).lower()).lower()
            if not hex_value.startswith("0x") or is_grease_codepoint(hex_value):
                continue
            name = TLS_SIGNATURE_ALGORITHM_NAMES.get(hex_value, hex_value)
            if name in seen:
                continue
            seen.add(name)
            schemes.append(name)
        if schemes:
            return schemes

    # Fallback path: parse values from field strings.
    raw_values = _collect_tls_values(
        tls,
        attr_names=(
            "handshake_sig_hash_alg",
            "handshake_sig_hash_algs",
            "handshake_sig_hash_algorithm",
            "handshake_signature_algorithm",
            "handshake_signature_algorithms",
        ),
        key_fragments=("sig_hash_alg", "signature_algorithm"),
        exclude_key_fragments=(
            "sig_hash_alg_len",
            "sig_hash_alg_hash",
            "sig_hash_alg_signature",
            "sig_hash_alg_tree",
            "signature_algorithm_cert",
            "signature_algorithms_cert",
            "len",
            "length",
        ),
    )
    schemes: list[str] = []
    seen: set[str] = set()
    for value in raw_values:
        for candidate_text in _candidate_field_strings(value):
            for hex_val in _extract_u16_hex_candidates(candidate_text):
                normalised = _normalize_u16_hex(hex_val).lower()
                name = TLS_SIGNATURE_ALGORITHM_NAMES.get(normalised, normalised)
                if name in seen:
                    continue
                seen.add(name)
                schemes.append(name)
    return schemes


def _extract_client_cipher_suites_from_all_fields(pkt: Any, tls: Any) -> tuple[list[str], list[str]]:
    # Primary path requested: pkt.tls.handshake_ciphersuite.all_fields -> field.raw_value
    layer_for_all_fields = getattr(pkt, "tls", None) or getattr(pkt, "ssl", None) or tls

    hexes: list[str] = []
    names: list[str] = []
    seen_hexes: set[str] = set()
    seen_names: set[str] = set()

    field_group = getattr(layer_for_all_fields, "handshake_ciphersuite", None)
    all_fields = getattr(field_group, "all_fields", None)
    if all_fields:
        for field in all_fields:
            raw_value = getattr(field, "raw_value", None)
            if raw_value is None:
                continue
            # User-provided method returns values like '1302', 'c02f', ...
            hex_value = _normalize_u16_hex(str(raw_value).lower())
            if not hex_value.startswith("0x") or is_grease_codepoint(hex_value):
                continue
            if hex_value in seen_hexes:
                continue
            seen_hexes.add(hex_value)
            hexes.append(hex_value)
            name = _resolve_cipher_name_from_field(field, hex_value)
            if name not in seen_names:
                seen_names.add(name)
                names.append(name)
    return hexes, names


def _extract_client_cipher_suites(tls: Any) -> tuple[list[str], list[str]]:
    raw_values = _collect_tls_values(
        tls,
        attr_names=("handshake_ciphersuite", "handshake_cipher_suite", "handshake_ciphersuites"),
        key_fragments=("handshake_ciphersuite", "handshake_cipher_suite", "handshake_ciphersuites"),
        exclude_key_fragments=("len", "length", "showname", "show"),
    )

    hexes: list[str] = []
    names: list[str] = []
    seen_hexes: set[str] = set()
    seen_names: set[str] = set()
    for value in raw_values:
        for candidate_text in _candidate_field_strings(value):
            for hex_value in _extract_u16_hex_candidates(candidate_text):
                if hex_value in seen_hexes:
                    continue
                seen_hexes.add(hex_value)
                hexes.append(hex_value)

                name = _resolve_cipher_name(hex_value)
                if name not in seen_names:
                    seen_names.add(name)
                    names.append(name)
    return hexes, names


def parse_client_hello(pkt: Any) -> TlsClientHelloInfo | None:
    tls = getattr(pkt, "tls", None) or getattr(pkt, "ssl", None)
    ip = _get_ip_layer(pkt)
    tcp = getattr(pkt, "tcp", None)
    if tls is None or ip is None or tcp is None:
        return None

    types = _parse_handshake_types(tls)
    if "1" not in types:
        return None

    dst_port_raw = getattr(tcp, "dstport", "0")
    try:
        dst_port = int(str(dst_port_raw))
    except ValueError:
        dst_port = 0

    cipher_hexes, cipher_names = _extract_client_cipher_suites_from_all_fields(pkt, tls)
    if not cipher_hexes:
        cipher_hexes, cipher_names = _extract_client_cipher_suites(tls)

    return TlsClientHelloInfo(
        src_ip=str(getattr(ip, "src", "")),
        dst_ip=str(getattr(ip, "dst", "")),
        dst_port=dst_port,
        sni=_extract_sni(tls),
        offered_cipher_hexes=cipher_hexes,
        offered_cipher_names=cipher_names,
        supported_versions=_extract_supported_versions(tls),
        supported_groups=tuple(_extract_supported_groups(tls)),
        signature_algorithms=tuple(_extract_signature_algorithms(tls)),
    )


def parse_tls_connection_observation(pkt: Any) -> TlsConnectionObservation | None:
    tls = getattr(pkt, "tls", None) or getattr(pkt, "ssl", None)
    ip = _get_ip_layer(pkt)
    tcp = getattr(pkt, "tcp", None)
    if tls is None or ip is None or tcp is None:
        return None

    types = _parse_handshake_types(tls)
    if "1" in types:
        handshake_type = "1"
    elif "2" in types:
        handshake_type = "2"
    else:
        return None

    _, version_label = _extract_tls_version(tls)
    cipher_name = "-"
    if handshake_type == "2":
        cipher_hex = _normalize_hex(getattr(tls, "handshake_ciphersuite", ""))
        if cipher_hex == "":
            cipher_hex = _normalize_hex(getattr(tls, "handshake_cipher_suite", ""))
        cipher_raw = str(getattr(tls, "handshake_ciphersuite", "")).strip()
        showname = str(getattr(tls, "handshake_ciphersuite_showname", "")).strip()
        cipher_name = _resolve_cipher_name(cipher_raw or cipher_hex, showname)

    dst_port_raw = getattr(tcp, "dstport", "0")
    try:
        dst_port = int(str(dst_port_raw))
    except ValueError:
        dst_port = 0

    return TlsConnectionObservation(
        handshake_type=handshake_type,
        src_ip=str(getattr(ip, "src", "")),
        dst_ip=str(getattr(ip, "dst", "")),
        dst_port=dst_port,
        tls_version=version_label or "-",
        cipher_name=cipher_name or "-",
        sni=_extract_sni(tls),
    )


def parse_server_hello(pkt: Any) -> TlsHandshakeInfo | None:
    tls = getattr(pkt, "tls", None) or getattr(pkt, "ssl", None)
    ip = _get_ip_layer(pkt)
    tcp = getattr(pkt, "tcp", None)
    if tls is None or ip is None or tcp is None:
        return None

    types = _parse_handshake_types(tls)
    if "2" not in types:
        return None

    version_hex, version_label = _extract_tls_version(tls)

    cipher_hex = _normalize_hex(getattr(tls, "handshake_ciphersuite", ""))
    if cipher_hex == "":
        cipher_hex = _normalize_hex(getattr(tls, "handshake_cipher_suite", ""))
    cipher_raw = str(getattr(tls, "handshake_ciphersuite", "")).strip()
    showname = str(getattr(tls, "handshake_ciphersuite_showname", "")).strip()
    cipher_name = _resolve_cipher_name(cipher_raw or cipher_hex, showname)
    sni = _extract_sni(tls)

    src_port_raw = getattr(tcp, "srcport", "0")
    dst_port_raw = getattr(tcp, "dstport", "0")
    try:
        src_port = int(str(src_port_raw))
    except ValueError:
        src_port = 0
    try:
        dst_port = int(str(dst_port_raw))
    except ValueError:
        dst_port = 0

    # Normalize to client->server orientation so service correlation lines up
    # with ClientHello (dst is server endpoint).
    server_ip = str(getattr(ip, "src", ""))
    client_ip = str(getattr(ip, "dst", ""))
    server_port = src_port or dst_port

    # Server's selected key_share group (single entry in ServerHello).
    groups = _extract_supported_groups(tls)
    key_share_group = groups[0] if groups else None

    return TlsHandshakeInfo(
        version_hex=version_hex,
        version_label=version_label,
        cipher_hex=cipher_hex,
        cipher_name=cipher_name or cipher_hex,
        src_ip=client_ip,
        dst_ip=server_ip,
        dst_port=server_port,
        sni=sni,
        key_share_group=key_share_group,
    )


def _extract_sni(tls: Any) -> str | None:
    for attr in (
        "handshake_extensions_server_name",
        "handshake_extension_server_name",
        "handshake_extensions_server_name_server_name",
    ):
        value = getattr(tls, attr, None)
        if value:
            return str(value).strip()

    fields = getattr(tls, "_all_fields", {})
    for key, value in fields.items():
        if "server_name" not in key.lower():
            continue
        values = value if isinstance(value, list) else [value]
        for item in values:
            text = str(item).strip()
            if text and "." in text and " " not in text:
                return text
    return None
