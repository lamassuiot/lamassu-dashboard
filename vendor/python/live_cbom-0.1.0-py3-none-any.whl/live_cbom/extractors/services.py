from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class ServiceObservation:
    dst_ip: str
    dst_port: int
    crypto_refs: set[str] = field(default_factory=set)
    sni_values: set[str] = field(default_factory=set)
    client_offered_cipher_suites: set[str] = field(default_factory=set)
    server_negotiated_cipher_suites: set[str] = field(default_factory=set)
    client_supported_versions: set[str] = field(default_factory=set)
    server_supported_versions: set[str] = field(default_factory=set)
    # Hex→name map for all client-offered cipher suites (enables identifiers in CBOM).
    offered_cipher_hexes: dict[str, str] = field(default_factory=dict)
    # Named groups advertised by the client (supported_groups extension).
    supported_groups: set[str] = field(default_factory=set)
    # The single key-exchange group the server actually selected (key_share).
    negotiated_group: str | None = None
    # Signature schemes advertised by the client (signature_algorithms extension).
    # Keep list order to preserve client preference order from ClientHello.
    signature_algorithms: list[str] = field(default_factory=list)
    certificate_signature_algorithms: list[str] = field(default_factory=list)
    key_share_groups: list[str] = field(default_factory=list)
    psk_key_exchange_modes: list[str] = field(default_factory=list)


def observe_service(
    services: dict[str, ServiceObservation],
    ip: str,
    port: int,
    crypto_bom_ref: str | None = None,
) -> ServiceObservation:
    key = f"{ip}:{port}"
    entry = services.get(key)
    if entry is None:
        entry = ServiceObservation(dst_ip=ip, dst_port=port)
        services[key] = entry
    if crypto_bom_ref:
        entry.crypto_refs.add(crypto_bom_ref)
    return entry
