"""Packaged JSON schemas for live-cbom interchange contracts."""
