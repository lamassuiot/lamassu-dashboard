from __future__ import annotations

import json
from collections.abc import Iterator, Mapping
from pathlib import Path
from types import TracebackType
from typing import Any, TextIO

from live_cbom.observations import (
    OBSERVATION_SCHEMA_VERSION,
    ObservationMapping,
)


def _as_observations(payload: Any) -> Iterator[ObservationMapping]:
    if isinstance(payload, Mapping):
        if "observations" in payload and "schemaVersion" not in payload:
            yield from _as_observations(payload["observations"])
            return
        yield dict(payload)
        return
    if isinstance(payload, list):
        for item in payload:
            if not isinstance(item, Mapping):
                raise ValueError("each observation must be an object")
            yield dict(item)
        return
    raise ValueError("observation input must contain an object or array")


def iter_observations(path: str) -> Iterator[ObservationMapping]:
    """Read Observation v1 objects from JSON, NDJSON/JSONL, or YAML."""
    source = Path(path)
    suffix = source.suffix.lower()

    if suffix in {".ndjson", ".jsonl"}:
        with source.open("r", encoding="utf-8") as handle:
            for line_number, line in enumerate(handle, start=1):
                text = line.strip()
                if not text:
                    continue
                try:
                    payload = json.loads(text)
                except json.JSONDecodeError as error:
                    raise ValueError(
                        f"invalid NDJSON at {source}:{line_number}: {error}"
                    ) from error
                yield from _as_observations(payload)
        return

    if suffix in {".yaml", ".yml"}:
        try:
            import yaml
        except ImportError as error:
            raise RuntimeError(
                "YAML observation input requires PyYAML; "
                "install live-cbom[native]"
            ) from error
        with source.open("r", encoding="utf-8") as handle:
            for document in yaml.safe_load_all(handle):
                if document is not None:
                    yield from _as_observations(document)
        return

    with source.open("r", encoding="utf-8") as handle:
        yield from _as_observations(json.load(handle))


class ObservationWriter:
    """Streaming writer for canonical JSON, NDJSON/JSONL, or YAML."""

    def __init__(self, path: str) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._format = self.path.suffix.lower()
        self._handle: TextIO | None = None
        self._count = 0
        self._yaml: Any = None

    @property
    def count(self) -> int:
        return self._count

    def __enter__(self) -> "ObservationWriter":
        self._handle = self.path.open("w", encoding="utf-8", buffering=1)
        if self._format == ".json":
            self._handle.write("[\n")
        elif self._format in {".yaml", ".yml"}:
            try:
                import yaml
            except ImportError as error:
                self._handle.close()
                self._handle = None
                raise RuntimeError(
                    "YAML observation output requires PyYAML; "
                    "install live-cbom[native]"
                ) from error
            self._yaml = yaml
        return self

    def write(self, observation: Mapping[str, Any]) -> None:
        if self._handle is None:
            raise RuntimeError("ObservationWriter must be opened first")
        version = str(observation.get("schemaVersion", ""))
        if version != OBSERVATION_SCHEMA_VERSION:
            raise ValueError(
                "schemaVersion must be "
                f"{OBSERVATION_SCHEMA_VERSION!r}, got {version!r}"
            )

        payload = dict(observation)
        if self._format == ".json":
            if self._count:
                self._handle.write(",\n")
            self._handle.write(json.dumps(payload, sort_keys=True))
        elif self._format in {".yaml", ".yml"}:
            self._yaml.safe_dump(
                payload,
                self._handle,
                explicit_start=True,
                sort_keys=False,
            )
        else:
            self._handle.write(
                json.dumps(payload, separators=(",", ":"), sort_keys=True)
            )
            self._handle.write("\n")
        self._count += 1

    def __call__(self, observation: Mapping[str, Any]) -> None:
        self.write(observation)

    def close(self) -> None:
        if self._handle is None:
            return
        if self._format == ".json":
            self._handle.write("\n]\n")
        self._handle.close()
        self._handle = None

    def __exit__(
        self,
        _exc_type: type[BaseException] | None,
        _exc_value: BaseException | None,
        _traceback: TracebackType | None,
    ) -> None:
        self.close()
