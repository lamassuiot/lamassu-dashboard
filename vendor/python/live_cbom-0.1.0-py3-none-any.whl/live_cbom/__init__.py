"""Live-capture CBOM package."""

