from __future__ import annotations

import json
from collections.abc import Iterable, Mapping
from typing import Any

from live_cbom.analysis import ObservationProcessor
from live_cbom.cbom.registry import CryptoRegistry
from live_cbom.config import Config
from live_cbom.observations import (
    as_bool,
    decoded_observation_from_mapping,
    get_value,
)
from live_cbom.output.serialization import render_cbom_json


class BrowserAnalyzer:
    """Stateful in-browser analyzer intended to be hosted by Pyodide."""

    def __init__(self, options: Mapping[str, Any] | None = None) -> None:
        options = options or {}
        self.config = Config(
            interface="wiregasm",
            output_path="",
            flush_interval_sec=0,
            bom_component_name=str(
                get_value(
                    options,
                    "componentName",
                    "component_name",
                    default="wiregasm-capture",
                )
            ),
            bom_component_version=str(
                get_value(
                    options,
                    "componentVersion",
                    "component_version",
                    default="1.0.0",
                )
            ),
            compact=as_bool(
                get_value(options, "compact", default=False)
            ),
            keylog_available=as_bool(
                get_value(
                    options,
                    "keylogAvailable",
                    "keylog_available",
                    default=False,
                )
            ),
        )
        self.registry = CryptoRegistry(compact=self.config.compact)
        self.processor = ObservationProcessor(self.registry)

    def ingest(self, observations: Iterable[Mapping[str, Any]]) -> int:
        count = 0
        for payload in observations:
            if not isinstance(payload, Mapping):
                raise ValueError("each observation must be an object")
            self.processor.ingest(payload)
            count += 1
        return count

    def ingest_json(self, payload_json: str) -> int:
        payload = json.loads(payload_json)
        if isinstance(payload, Mapping):
            payload = get_value(payload, "observations", default=[payload])
        if not isinstance(payload, list):
            raise ValueError("observation payload must be an array or object")
        return self.ingest(payload)

    def finish_json(self, *, indent: int | None = 2) -> str:
        return render_cbom_json(self.registry, self.config, indent=indent)


_default_analyzer = BrowserAnalyzer()


def reset(options_json: str | None = None) -> None:
    """Reset the module-level analyzer used by the simple Pyodide API."""
    global _default_analyzer
    options = json.loads(options_json) if options_json else {}
    if not isinstance(options, Mapping):
        raise ValueError("browser options must be a JSON object")
    _default_analyzer = BrowserAnalyzer(options)


def ingest_json(payload_json: str) -> int:
    """Ingest one observation or a batch into the module-level analyzer."""
    return _default_analyzer.ingest_json(payload_json)


def finish_json(indent: int | None = 2) -> str:
    """Return the current module-level CycloneDX 1.7 CBOM JSON."""
    return _default_analyzer.finish_json(indent=indent)
