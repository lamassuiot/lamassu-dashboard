from __future__ import annotations

import logging
import os
import threading

from live_cbom.cbom.registry import CryptoRegistry
from live_cbom.config import Config
from live_cbom.output.serialization import render_cbom_json, validate_cbom_json

LOGGER = logging.getLogger(__name__)


class PeriodicWriter:
    def __init__(self, registry: CryptoRegistry, config: Config) -> None:
        self._registry = registry
        self._config = config
        self._timer: threading.Timer | None = None
        self._stop_event = threading.Event()

    def start(self) -> None:
        self._stop_event.clear()
        self._schedule()

    def stop(self) -> None:
        self._stop_event.set()
        if self._timer:
            self._timer.cancel()

    def flush_once(self) -> None:
        json_str = render_cbom_json(self._registry, self._config, indent=2)

        tmp_path = f"{self._config.output_path}.tmp"
        with open(tmp_path, "w", encoding="utf-8") as file_obj:
            file_obj.write(json_str)
            file_obj.flush()
            os.fsync(file_obj.fileno())
        os.replace(tmp_path, self._config.output_path)

        # Validation is best-effort; missing optional deps should not block output.
        try:
            errors = validate_cbom_json(json_str)
            if errors:
                LOGGER.error("CBOM schema validation errors: %s", errors)
        except Exception as exc:
            LOGGER.warning("CBOM validation skipped: %s", exc)

        LOGGER.info("CBOM flushed to %s", self._config.output_path)

    def _schedule(self) -> None:
        if self._stop_event.is_set():
            return
        self._timer = threading.Timer(self._config.flush_interval_sec, self._on_tick)
        self._timer.daemon = True
        self._timer.start()

    def _on_tick(self) -> None:
        try:
            self.flush_once()
        except Exception:
            LOGGER.exception("Periodic CBOM flush failed")
        finally:
            self._schedule()
