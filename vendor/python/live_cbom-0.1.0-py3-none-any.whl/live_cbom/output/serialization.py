from __future__ import annotations

from live_cbom.cbom.builder import build_bom
from live_cbom.cbom.registry import CryptoRegistry
from live_cbom.config import Config


def render_cbom_json(
    registry: CryptoRegistry,
    config: Config,
    *,
    indent: int | None = 2,
) -> str:
    """Build and serialize a CycloneDX 1.7 CBOM entirely in memory."""
    from cyclonedx.output import make_outputter
    from cyclonedx.schema import OutputFormat, SchemaVersion

    bom = build_bom(registry, config)
    return make_outputter(
        bom,
        OutputFormat.JSON,
        SchemaVersion.V1_7,
    ).output_as_string(indent=indent)


def validate_cbom_json(json_text: str) -> list[str]:
    """Return CycloneDX 1.7 validation errors.

    Kept separate from rendering so browser deployments can omit the optional
    validation dependency and its download/startup cost.
    """
    from cyclonedx.schema import SchemaVersion
    from cyclonedx.validation.json import JsonValidator

    result = JsonValidator(SchemaVersion.V1_7).validate_str(json_text)
    return [str(error) for error in result or ()]
