from __future__ import annotations

import asyncio
import logging
import threading
from collections.abc import Callable
from typing import Any

import pyshark

LOGGER = logging.getLogger(__name__)


PacketCallback = Callable[[Any], None]


class PacketListener:
    def __init__(self, interface: str, keylog_path: str | None = None) -> None:
        self._interface = interface
        self._keylog_path = keylog_path
        self._capture: pyshark.LiveCapture | None = None
        self._event_loop: asyncio.AbstractEventLoop | None = None
        self._callbacks: list[PacketCallback] = []
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None

    def register_callback(self, on_packet: PacketCallback) -> None:
        self._callbacks.append(on_packet)

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._run, daemon=True, name="packet-listener")
        self._thread.start()

    def stop(self) -> None:
        self._stop_event.set()
        if self._capture is not None:
            try:
                self._capture.close()
            except Exception:
                LOGGER.debug("Failed to close pyshark capture cleanly", exc_info=True)
        if self._thread:
            self._thread.join(timeout=5)

    def _run(self) -> None:
        try:
            self._event_loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self._event_loop)
            # BPF capture filter (kernel-level, very fast): restrict to TCP only.
            # This reduces tshark's workload before the display filter is applied.
            # Note: BPF works on real interfaces; on the "any" pseudo-interface
            # the kernel accepts "tcp" but silently ignores it on some kernels,
            # which is harmless — the display filter still applies correctly.
            bpf = "tcp"

            # Display filter (tshark-level): only pass TLS handshakes and bare
            # TCP SYNs so connection tracking starts before the TLS layer appears.
            df = "tls or (tcp.flags.syn == 1 and tcp.flags.ack == 0)"

            # -l  forces line-buffered stdout so tshark flushes each packet
            #     immediately instead of waiting for a full output buffer.
            custom_parameters = [
                "-l",
                "-o",
                "tcp.desegment_tcp_streams:TRUE",
                "-o",
                "tls.desegment_ssl_records:TRUE",
                "-o",
                "tls.desegment_ssl_application_data:TRUE",
            ]
            if self._keylog_path:
                # Lets tshark decrypt TLS 1.3 records (e.g. from secrets an
                # `ecapture tls -m keylog` sidecar is writing to this file).
                custom_parameters += ["-o", f"tls.keylog_file:{self._keylog_path}"]

            self._capture = pyshark.LiveCapture(
                interface=self._interface,
                bpf_filter=bpf,
                display_filter=df,
                custom_parameters=custom_parameters,
                eventloop=self._event_loop,
            )
            for pkt in self._capture.sniff_continuously():
                if self._stop_event.is_set():
                    break
                for callback in self._callbacks:
                    try:
                        callback(pkt)
                    except Exception:
                        LOGGER.exception("Packet callback failed")
        except Exception as exc:
            if not self._stop_event.is_set():
                msg = str(exc).lower()
                if "permission" in msg or "operation not permitted" in msg or "cap_net" in msg:
                    LOGGER.error(
                        "Packet capture failed: insufficient privileges. "
                        "Run as root or grant tshark CAP_NET_RAW+CAP_NET_ADMIN: "
                        "sudo setcap cap_net_raw,cap_net_admin+eip $(which tshark)"
                    )
                else:
                    LOGGER.exception("Packet capture loop crashed")
        finally:
            if self._capture is not None:
                try:
                    self._capture.close()
                except Exception:
                    LOGGER.debug("Error closing capture during shutdown", exc_info=True)
            if self._event_loop is not None:
                try:
                    self._event_loop.stop()
                    self._event_loop.close()
                except Exception:
                    LOGGER.debug("Error closing asyncio event loop", exc_info=True)


def read_pcap(pcap_path: str, callback: PacketCallback, keylog_path: str | None = None) -> None:
    """Read all packets from a PCAP file and invoke *callback* for each one.

    Uses the same tshark display filter as live capture so that only TLS
    handshakes and bare TCP SYNs are processed.

    Args:
        pcap_path:   Path to the ``.pcap`` / ``.pcapng`` file.
        callback:    Function called with each decoded :class:`pyshark.packet.packet.Packet`.
        keylog_path: Optional NSS-format TLS key-log file (e.g. from `ecapture
                     tls -m keylog`) used to decrypt TLS 1.3 records.
    """
    import asyncio

    # Mirror the display filter used by LiveCapture.
    display_filter = "tls or (tcp.flags.syn == 1 and tcp.flags.ack == 0)"

    event_loop = asyncio.new_event_loop()
    asyncio.set_event_loop(event_loop)

    custom_parameters = [
        "-o", "tcp.desegment_tcp_streams:TRUE",
        "-o", "tls.desegment_ssl_records:TRUE",
        "-o", "tls.desegment_ssl_application_data:TRUE",
    ]
    if keylog_path:
        custom_parameters += ["-o", f"tls.keylog_file:{keylog_path}"]

    capture = pyshark.FileCapture(
        pcap_path,
        display_filter=display_filter,
        custom_parameters=custom_parameters,
        eventloop=event_loop,
    )
    try:
        for pkt in capture:
            try:
                callback(pkt)
            except Exception:
                LOGGER.exception("Packet callback failed")
    finally:
        try:
            capture.close()
        except Exception:
            LOGGER.debug("Failed to close FileCapture cleanly", exc_info=True)
        try:
            event_loop.stop()
            event_loop.close()
        except Exception:
            LOGGER.debug("Error closing asyncio event loop", exc_info=True)
