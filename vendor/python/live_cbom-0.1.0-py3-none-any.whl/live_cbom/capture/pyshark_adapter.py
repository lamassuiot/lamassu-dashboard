from __future__ import annotations

from typing import Any

from live_cbom.extractors.certificates import parse_certificate
from live_cbom.extractors.tls import (
    parse_certificate_request,
    parse_client_hello,
    parse_server_hello,
    parse_tls_connection_observation,
)
from live_cbom.observations import (
    DecodedObservation,
    ObservationMapping,
    decoded_observation_to_mapping,
)


def _parse_int(value: Any, default: int = 0) -> int:
    try:
        return int(str(value))
    except (TypeError, ValueError):
        return default


def _is_tcp_syn_without_ack(tcp: Any) -> bool:
    syn = str(
        getattr(tcp, "flags_syn", getattr(tcp, "flags_syn_raw", "0"))
    ).strip().lower()
    ack = str(
        getattr(tcp, "flags_ack", getattr(tcp, "flags_ack_raw", "0"))
    ).strip().lower()
    syn_true = syn in {"1", "true", "set", "yes"}
    ack_true = ack in {"1", "true", "set", "yes"}

    flags_value = str(getattr(tcp, "flags", "")).strip().lower()
    if flags_value.startswith("0x"):
        try:
            bitmask = int(flags_value, 16)
            syn_true = syn_true or bool(bitmask & 0x02)
            ack_true = ack_true or bool(bitmask & 0x10)
        except ValueError:
            pass

    return syn_true and not ack_true


def observation_from_packet(pkt: Any) -> ObservationMapping:
    """Decode one PyShark packet into the canonical Observation v1 mapping."""
    ip_layer = getattr(pkt, "ip", None) or getattr(pkt, "ipv6", None)
    tcp = getattr(pkt, "tcp", None)
    src_ip = (
        str(getattr(ip_layer, "src", "")) if ip_layer is not None else ""
    )
    dst_ip = (
        str(getattr(ip_layer, "dst", "")) if ip_layer is not None else ""
    )
    src_port = (
        _parse_int(getattr(tcp, "srcport", 0)) if tcp is not None else 0
    )
    dst_port = (
        _parse_int(getattr(tcp, "dstport", 0)) if tcp is not None else 0
    )
    stream_id = (
        str(getattr(tcp, "stream", "")) if tcp is not None else ""
    )

    return decoded_observation_to_mapping(
        DecodedObservation(
            src_ip=src_ip,
            dst_ip=dst_ip,
            src_port=src_port,
            dst_port=dst_port,
            stream_id=stream_id or None,
            tcp_syn=tcp is not None and _is_tcp_syn_without_ack(tcp),
            tls_connection=parse_tls_connection_observation(pkt),
            client_hello=parse_client_hello(pkt),
            server_hello=parse_server_hello(pkt),
            certificates=tuple(parse_certificate(pkt)),
            certificate_requested=parse_certificate_request(pkt),
        )
    )
