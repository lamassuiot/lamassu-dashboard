from __future__ import annotations

from typing import Any

from live_cbom.extractors.certificates import parse_certificate
from live_cbom.extractors.tls import (
    _extract_certificate_signature_algorithms,
    _extract_server_key_exchange_group,
    _extract_signature_algorithms,
    _parse_handshake_types,
    is_hello_retry_request,
    parse_certificate_request,
    parse_client_hello,
    parse_hello_retry_request,
    parse_server_hello,
    parse_tls_connection_observation,
)
from live_cbom.observations import (
    DecodedObservation,
    ObservationMapping,
    decoded_observation_to_mapping,
)


def _parse_int(value: Any, default: int = 0) -> int:
    try:
        return int(str(value))
    except (TypeError, ValueError):
        return default


def _is_tcp_syn_without_ack(tcp: Any) -> bool:
    syn = str(
        getattr(tcp, "flags_syn", getattr(tcp, "flags_syn_raw", "0"))
    ).strip().lower()
    ack = str(
        getattr(tcp, "flags_ack", getattr(tcp, "flags_ack_raw", "0"))
    ).strip().lower()
    syn_true = syn in {"1", "true", "set", "yes"}
    ack_true = ack in {"1", "true", "set", "yes"}

    flags_value = str(getattr(tcp, "flags", "")).strip().lower()
    if flags_value.startswith("0x"):
        try:
            bitmask = int(flags_value, 16)
            syn_true = syn_true or bool(bitmask & 0x02)
            ack_true = ack_true or bool(bitmask & 0x10)
        except ValueError:
            pass

    return syn_true and not ack_true


def _frame_numbers(pkt: Any) -> tuple[int, ...]:
    value = getattr(pkt, "number", None)
    if value is None:
        frame_info = getattr(pkt, "frame_info", None)
        value = getattr(frame_info, "number", None)
    frame_number = _parse_int(value)
    return (frame_number,) if frame_number > 0 else ()


def _certificate_role(
    *,
    has_certificates: bool,
    has_server_hello: bool,
    certificate_requested: bool,
    src_port: int,
    dst_port: int,
) -> str | None:
    if not has_certificates:
        return None
    if has_server_hello or certificate_requested:
        return "server"
    if src_port and dst_port:
        return "server" if src_port < dst_port else "client"
    return "server"


def _phase_entries(
    pkt: Any,
    *,
    certificate_role: str | None,
) -> dict[str, tuple[dict[str, Any], ...]]:
    tls = getattr(pkt, "tls", None) or getattr(pkt, "ssl", None)
    if tls is None:
        return {}
    types = _parse_handshake_types(tls)
    frame_numbers = list(_frame_numbers(pkt))

    def base(source: str, destination: str) -> dict[str, Any]:
        entry: dict[str, Any] = {
            "direction": {
                "source": source,
                "destination": destination,
            },
            "status": "observed",
            "presence": "confirmed",
        }
        if frame_numbers:
            entry["frame_numbers"] = frame_numbers
        return entry

    phases: dict[str, tuple[dict[str, Any], ...]] = {}
    signatures = _extract_signature_algorithms(tls)

    if is_hello_retry_request(pkt):
        entry = base("server", "client")
        entry["requested"] = {
            "key_share_group": parse_hello_retry_request(pkt)
        }
        phases["hello_retry_request"] = (entry,)

    if "8" in types:
        phases["encrypted_extensions"] = (base("server", "client"),)

    if "12" in types:
        entry = base("server", "client")
        group = _extract_server_key_exchange_group(tls)
        dhe_parameters = any(
            getattr(tls, attribute, None) is not None
            for attribute in ("handshake_p", "handshake_g")
        )
        entry["selected"] = {
            "key_exchange": {
                "family": (
                    "ECDHE" if group else ("DHE" if dhe_parameters else "unknown")
                ),
                "group": group,
            },
            "signature_scheme": signatures[-1] if signatures else None,
        }
        phases["server_key_exchange"] = (entry,)

    if "13" in types:
        entry = base("server", "client")
        entry["requested"] = {
            "signature_schemes": signatures,
            "certificate_signature_schemes": (
                _extract_certificate_signature_algorithms(tls)
            ),
            "certificate_authorities": [],
        }
        phases["certificate_request"] = (entry,)

    if "15" in types and signatures:
        role = certificate_role or (
            "server"
            if _parse_int(getattr(getattr(pkt, "tcp", None), "srcport", 0))
            < _parse_int(getattr(getattr(pkt, "tcp", None), "dstport", 0))
            else "client"
        )
        entry = base(
            role,
            "client" if role == "server" else "server",
        )
        entry["selected"] = {"signature_scheme": signatures[-1]}
        phases[f"{role}_certificate_verify"] = (entry,)

    if "16" in types:
        entry = base("client", "server")
        client_point = getattr(tls, "handshake_client_point", None)
        length = None
        if client_point is not None:
            raw = str(
                getattr(client_point, "raw_value", None) or client_point
            )
            cleaned = raw.replace(":", "").replace(" ", "")
            if cleaned.startswith("0x"):
                cleaned = cleaned[2:]
            if cleaned and len(cleaned) % 2 == 0:
                length = len(cleaned) // 2
        entry["selected"] = {
            "key_exchange_family": "ECDHE" if client_point else "unknown",
            "public_value_length_bytes": length,
        }
        phases["client_key_exchange"] = (entry,)
    return phases


def observation_from_packet(pkt: Any) -> ObservationMapping:
    """Decode one PyShark packet into a phased TLS crypto observation."""
    ip_layer = getattr(pkt, "ip", None) or getattr(pkt, "ipv6", None)
    tcp = getattr(pkt, "tcp", None)
    src_ip = (
        str(getattr(ip_layer, "src", "")) if ip_layer is not None else ""
    )
    dst_ip = (
        str(getattr(ip_layer, "dst", "")) if ip_layer is not None else ""
    )
    src_port = (
        _parse_int(getattr(tcp, "srcport", 0)) if tcp is not None else 0
    )
    dst_port = (
        _parse_int(getattr(tcp, "dstport", 0)) if tcp is not None else 0
    )
    stream_id = (
        str(getattr(tcp, "stream", "")) if tcp is not None else ""
    )
    client_hello = parse_client_hello(pkt)
    server_hello = parse_server_hello(pkt)
    certificates = tuple(parse_certificate(pkt))
    certificate_requested = parse_certificate_request(pkt)
    certificate_role = _certificate_role(
        has_certificates=bool(certificates),
        has_server_hello=server_hello is not None,
        certificate_requested=certificate_requested,
        src_port=src_port,
        dst_port=dst_port,
    )
    phases = _phase_entries(pkt, certificate_role=certificate_role)
    server_verify = phases.get("server_certificate_verify", ())
    client_verify = phases.get("client_certificate_verify", ())

    return decoded_observation_to_mapping(
        DecodedObservation(
            src_ip=src_ip,
            dst_ip=dst_ip,
            src_port=src_port,
            dst_port=dst_port,
            stream_id=stream_id or None,
            tcp_syn=tcp is not None and _is_tcp_syn_without_ack(tcp),
            tls_connection=parse_tls_connection_observation(pkt),
            client_hello=client_hello,
            server_hello=server_hello,
            certificates=certificates,
            certificate_role=certificate_role,
            certificate_requested=certificate_requested,
            ip_version=(
                6
                if getattr(pkt, "ipv6", None) is not None
                else 4
            ),
            frame_numbers=_frame_numbers(pkt),
            server_handshake_signature_scheme=(
                server_verify[0]["selected"]["signature_scheme"]
                if server_verify
                else None
            ),
            client_handshake_signature_scheme=(
                client_verify[0]["selected"]["signature_scheme"]
                if client_verify
                else None
            ),
            phase_entries=phases,
        )
    )
